jQuery(function($) {
	
    $("#mainslider").show();
    $("#mainslider1").hide();
	
    $("#leftPanelCheckboxListing").show();
    $("#jsdisablecheckboxlisting").hide();
    
    var phototitle = $('#phototitle').val();
    var photodesc = $('#photodesc').val();
    var photoplace = $('#photoplace').val();
    var photopeople = $('#photopeople').val();
    var photosource = $('#photosource').val();
    
    function formatTitle(title, currentArray, currentIndex, currentOpts) {
        var photoDesc = '';
       
        $(".message_box").each(function(){
           if($(this).find('.pcounter').val() == currentIndex){
              photoDesc = '<div id="tip7-title"><span><a href="javascript:;" onclick="$.fancybox.close();"></a></span>';
              
               photoDesc += '<div class="gallery_inner1">';
                                
                                if($(this).find('.phototitle').val() != '')
                                {
                                photoDesc += '<h3>'+phototitle+': <span class="phototitle">'+$(this).find('.phototitle').val()+'</span></h3>';
                                }
                                
                                if($(this).find('.photodesc').val() != '')
                                {
                                photoDesc += '<h3>'+photodesc+': <span class="photodesc">'+$(this).find('.photodesc').val()+'</span></h3>';
                                }
                                
                                if($(this).find('.photoplace').val() != '')
                                {
                                photoDesc += '<h3>'+photoplace+': <span class="photodesc">'+$(this).find('.photoplace').val()+'</span></h3>';
                                }
                                
                                if($(this).find('.photopeople').val() != '')
                                {
                                photoDesc += '<h3>'+photopeople+': <span class="photodesc">'+$(this).find('.photopeople').val()+'</span></h3>';
                                }
                                 if($(this).find('.photosource').val() != '')
                                {
                                photoDesc += '<h3>'+photosource+': <span class="photodesc">'+$(this).find('.photosource').val()+'</span></h3>';
                                }
                                photoDesc +='</div>';
              
              
//<b>' + title + '</b>' +  ($(this).find('.photoplace').val() && $(this).find('.photoplace').val().length ?  '<br/>Place : '+$(this).find('.photoplace').val()  : '' ) +  ($(this).find('.photopeople').val() && $(this).find('.photopeople').val().length ? '<br/>People : ' +$(this).find('.photopeople').val() : '' )+'</div>';
           }
        });
        return photoDesc;
    }   

    var photo_url           = $('#photo_url').val();
    var photo_small_url     = $('#photo_small_url').val();
    var photo_medium_url    = $('#photo_medium_url').val();  	

    var baseURL = $("#basepathvalue").val();
    var lang      = $('#language').val();
	
    var main_checkbox_obj = $("#leftPanelCheckboxListing > .head");
    var year_checkbox_obj = $("#leftPanelCheckboxListing");
    
    var total_check_box = (year_checkbox_obj.find("li").length) - 1;
	
    main_checkbox_obj.find("input:checkbox").change(function () {
        if($(this).attr('checked') == 'checked')
        {
            year_checkbox_obj.find("li").each(function () {
                var chkobj = $(this).find("input:checkbox");
                if(chkobj.attr('id') != 'CheckBox1')
                {
                    chkobj.attr('checked', 'checked');
                    $(this).find("label").addClass('checked');
                }
            });
        }
        else
        {
            year_checkbox_obj.find("li").each(function () {
                var chkobj = $(this).find("input:checkbox");
                chkobj.removeAttr('checked');
                $(this).find("label").removeClass('checked');
            });
        }
        $(this).getFilterData();
    });
	
    year_checkbox_obj.find("input:checkbox").change(function () {
        
        var total_checked = year_checkbox_obj.find("input:checked").length;
        if(main_checkbox_obj.find("input:checkbox").attr('checked') == 'checked')
        {    
            total_checked = total_checked - 1;
        }    
        
        if(total_check_box == total_checked)
        {
            main_checkbox_obj.find("input:checkbox").attr('checked', 'checked');
            main_checkbox_obj.find("label").addClass('checked');
        }
        else
        {
            main_checkbox_obj.find("input:checkbox").removeAttr('checked');
            main_checkbox_obj.find("label").removeClass('checked');
        }
        if($(this).val() != "on")
            $(this).getFilterData();
    });
    
    $.fn.getFilterData = function()
    {
        var selected_checkbox = '';
        $("#leftPanelCheckboxListing").find("input:checked").each(function () {
            var chkbox_val = $(this).val();
            if(chkbox_val != "" && chkbox_val != 'on')
            { 
                selected_checkbox += chkbox_val+'##';
            }   
        });

        var extra_url = $("#display_photos_url").val();
        if(extra_url == '' || extra_url == undefined)
        {
            var pageurl = baseURL+"/photos_ajaxthumbview";
        }
        else
        {
            var pageurl = baseURL+"/photos_ajaxthumbview/"+extra_url;
        }
	
        $.ajax({
            type: "POST", 
            url: pageurl,
            dataType: 'json',
            data: {
                language : lang, 
                checkbox_filter : 1, 
                selected_checkbox: selected_checkbox
            },
            beforeSend: function () {
                // SHOW LOADING
                $("#GalleryLoaderDisplay").show();
            },
            success: function(data) {
                var ulinnerdata = "";
                if(data.length > 0){
                    var photoid = "";
				 
                    for(var i=0; i<data.length; i++){                  
                        mediumImage  = photo_medium_url+data[i].photo_filename;					
                        photoid = data[i].photo_id;
						alert(photoid);
                        ulinnerdata +="<li id='photothumb_"+photoid+"' class='message_box'>";
                        ulinnerdata +="<a rel='example_group' img_id='"+photoid+"' href='"+photo_url+data[i].photo_filename+"' title='"+data[i].photo_title+"' class='productImage pop'><img src='"+mediumImage+"' img_id='"+photoid+"' alt='"+data[i].photo_title+"' height='135' width='129' /></a>";
                        ulinnerdata +="<span class='title'>"+data[i].photo_title+"</span>";
                        ulinnerdata +="<input type='hidden' class='pcounter' name='photocounter_ "+i+"' id= 'photocounter_ "+i+"' value='"+i+"' />";
                        
                         ulinnerdata +="<input type='hidden' class='phototitle' name='phototitle_ " +photoid+ "' id= 'phototitle_ "+photoid+ "' value='"+data[i].photo_title+"' />";
                      ulinnerdata +="<input type='hidden' class='photodesc' name='photodesc_ " +photoid+ "' id= 'photodesc_ " +photoid+ "' value='"+data[i].photo_description+"' />";
                        
                    ulinnerdata +="<input type='hidden' class='photoplace' name='photoplace_ " +photoid+ "' id= 'photoplace_ "+photoid+ "' value='"+data[i].photo_place+"' />";
                      ulinnerdata +="<input type='hidden' class='photopeople' name='photopeople_ " +photoid+ "' id= 'photopeople_ " +photoid+ "' value='"+data[i].photo_people+"' />";
                       ulinnerdata +="<input type='hidden' class='photosource' name='photosource_ " +photoid+ "' id= 'photosource_ " +photoid+ "' value='"+data[i].photo_source+"' />";
                      
                      ulinnerdata +="</li>";	                   
                    }

                    $("#photo_id").val(photoid);
                    $("#photoDisplayCounter").val(i);
                    $(".facebook_style a").attr("id",photoid);
                    $("#selected_checkbox").val(selected_checkbox);
                    $("#updates").html(ulinnerdata);
                }else{
                    ulinnerdata += "<li style='background: none; width: 804px; text-align: center; font-weight:bold; '>No Record Found.</li>";
                    $("#updates").html(ulinnerdata);
                }

            //   $('#photoLoading').hide();    
            }

        }).done(function() { 
            // START CALL FANCYBOX
            $("a[rel=example_group]").fancybox({
                'transitionIn'		: 'elastic',
                'transitionOut'		: 'fade',
                'titlePosition' 	: 'inside',
                'titleFormat'		: formatTitle
            });                   
        // STOP CALL FANCYBOX 
        });
        $("#GalleryLoaderDisplay").hide();
    };
	
    $("#Slider4").slider({
        from: 1869, 
        to: 1948,
        scale: [$("#inputslidetest").val()],  
        limits: false,
        step: 1,
        dimension: '',
        skin: "blue",
        callback: function( value ){
            
            // START TO UNCHECK ALL CHECKBOX
            $("#leftPanelCheckboxListing").find("li").each(function () {
                var chkobj = $(this).find("input:checkbox");
                chkobj.removeAttr('checked');
                $(this).find("label").removeClass('checked');
            });
            // END TO UNCHECK ALL CHECKBOX  
            
            checkbox_flag = false;
            slider_flag = true;
            var basepathval = $("#basepath").val();  
            var year_range = value.split(";");
            from_year = parseInt(year_range[0]);
            to_year = parseInt(year_range[1]);

            $("#yearstartspan").html(from_year);
            $("#yearendspan").html(to_year);

            var extra_url = $("#display_photos_url").val();
            
            if(extra_url == '' || extra_url == undefined)
            {
                var pageurl = baseURL+"/get_ajax_thumb_photos_data";
            }
            else
            {
                var pageurl = baseURL+"/get_ajax_thumb_photos_data/"+extra_url;
            }

            $.ajax({
                type: "POST", 
                url: pageurl,
                dataType: 'json',
                data: {
                    language : lang, 
                    from_year : from_year, 
                    to_year: to_year
                },
                beforeSend: function ( ) {
                    // SHOW LOADING
                    $("#GalleryLoaderDisplay").show();
                },
                success: function(data) {								
				
                    var photoList = '';
                    var photoDesc = ''; 
                    var displayDesc = '';
                    var ulinnerdata = "";
                    if(data.length > 0){
							
                        var year_range = value.split(";");
                        var selected_checkbox = year_range[0]+"-"+year_range[1]+"##";
                        var photoid = "";
                        for(var i=0; i<data.length; i++){	
                            mediumImage  = photo_medium_url+data[i].photo_filename;
                            photoid = data[i].photo_id;		
							ulinnerdata +="<li id='photothumb_"+photoid+"' class='message_box'>";
                            ulinnerdata +="<a rel='example_group' img_id='"+photoid+"' href='"+photo_url+data[i].photo_filename+"' title='"+data[i].photo_title+"' class='productImage pop'><img src='"+mediumImage+"' img_id='"+photoid+"' alt='"+data[i].photo_title+"' height='135' width='129' /></a>";
                            ulinnerdata +="<span class='title'>"+data[i].photo_title+"</span>";
                          
                             ulinnerdata +="<input type='hidden' class='pcounter' name='photocounter_ "+i+"' id= 'photocounter_ "+i+"' value='"+i+"' />";
                        
                         ulinnerdata +="<input type='hidden' class='phototitle' name='phototitle_ " +photoid+ "' id= 'phototitle_ "+photoid+ "' value='"+data[i].photo_title+"' />";
                      ulinnerdata +="<input type='hidden' class='photodesc' name='photodesc_ " +photoid+ "' id= 'photodesc_ " +photoid+ "' value='"+data[i].photo_description+"' />";
                        
                    ulinnerdata +="<input type='hidden' class='photoplace' name='photoplace_ " +photoid+ "' id= 'photoplace_ "+photoid+ "' value='"+data[i].photo_place+"' />";
                      ulinnerdata +="<input type='hidden' class='photopeople' name='photopeople_ " +photoid+ "' id= 'photopeople_ " +photoid+ "' value='"+data[i].photo_people+"' />";
                       ulinnerdata +="<input type='hidden' class='photosource' name='photosource_ " +photoid+ "' id= 'photosource_ " +photoid+ "' value='"+data[i].photo_source+"' />";
                          
                          
                            ulinnerdata +="</li>";;	
                        }

                        $("#photo_id").val(photoid);
                        $("#photoDisplayCounter").val(i);
                        $(".facebook_style a").attr("id",photoid);
                        $("#selected_checkbox").val(selected_checkbox);					
                        $("#updates").html(ulinnerdata);
                    }else{
                        ulinnerdata += "<li style='background: none; width: 804px; text-align: center; font-weight:bold; '>No Record Found.</li>";
                        $("#updates").html(ulinnerdata);
                    }
                }
            }).done(function() { 
                // START CALL FANCYBOX
                $("a[rel=example_group]").fancybox({
                    'transitionIn'		: 'elastic',
                    'transitionOut'		: 'fade',
                    'titlePosition' 	: 'inside',
                    'titleFormat'		: formatTitle
                });                   
                // STOP CALL FANCYBOX
                $("#GalleryLoaderDisplay").hide();
            });
        } 
    });
});