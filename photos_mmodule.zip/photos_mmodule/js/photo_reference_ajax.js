jQuery(function ($) {

    $('#with_js').css('display', 'block');
    $('#without_js').css('display', 'none');
    $('#without_js').html('');

    //$('#referenceItem').css('display', 'block');
    $('#jsstatus').val('1');
    var base_url = $('#trans_url').val();
		var baseurl = $('#base_url').val();
    $('.referenceContent').css('display', 'none');
    $('.otherRef').css('display', 'block');
    $('.otherRef').toggle(function () {
        var currentID = $('#currentImgId').val();
        var activeTab = $('#activeTab').val();
        other_ref(currentID, activeTab, 1);
        $('.referenceContent').stop(1).slideDown('slow');
        $('#arrowimage').attr('src', baseurl + '/sites/default/files/ghp_photos/images/uparrow.png');
    }, function () {
        $('.referenceContent').stop(1).slideUp('slow');
        $('#arrowimage').attr('src', baseurl + '/sites/default/files/ghp_photos/images/downarrow.png');
    });


    $.fn.bindJqueryLibrary = function ()
    {
        // $(".fancybox").attr('rel', 'gallery').fancybox({
        $("a[rel=gallery]").fancybox({
            type: 'image',
            overlayShow: 'false',
            transitionIn: 'elastic',
            transitionOut: 'elastic',
            titlePosition: 'inside',
            titleFormat: formatCartoonTitle
        });
        $("a[rel=gallery_video_group]").fancybox({
            'transitionIn': 'elastic',
            'transitionOut': 'fade',
            'titlePosition': 'inside',
            'showNavArrows': false,
            'scrolling': 'no',
            'titleShow': false,
			onStart: function() {
		    initPlayers();
			}
        });
        //initPlayers();

        $("a[rel=gallery_audio_group]").fancybox({
            'transitionIn': 'elastic',
            'transitionOut': 'fade',
            'titlePosition': 'inside',
            'showNavArrows': false,
            'scrolling': 'no',
			'titleShow': false,
			
        });
        initAudioPlayers();

    }

    $.fn.bindJqueryLibrary();




    function formatCartoonTitle() {
        var cartoonDesc = '';
        cartoonDesc = '<div class="gallery_inner1">';
        if ($(this).attr('title') != '')
        {
            cartoonDesc += '<h3>' + $('#phototitle').val() + ': <span class="phototitle">' + $(this).attr('title') + '</span></h3>';
        }
        cartoonDesc += '</div>';
        return cartoonDesc;
    }
    /* Video Player */


    function initPlayers() {

        var video_url = $('#video_url').val();
        var video_image_url = $('#video_image_url').val();

        var quality = $('#quality').val();
        var video_file_url = video_url + quality + "/";

        var videoDisplay = '';

        videoDisplay += '[';
        for (i = 0; i < $("#videoGallery li").length; i++) {

            var videoFileName = $('#videoFilename' + i).val();
            if (videoFileName != undefined) {
                var vFileName = videoFileName.slice(0, videoFileName.lastIndexOf("."));
                // videoDisplay +=  '{ title: "'+$('#videoTitle'+i).val()+'", artist: "'+$('#videographerName'+i).val()+'", webmv: "'+video_file_url+vFileName+'.webm", m4v: "'+video_file_url+vFileName+'.mp4", poster: "'+video_image_url+"medium/"+$('#videoImage'+i).val()+'"}';

                videoDisplay += '{ webmv: "' + video_file_url + vFileName + '.webm", m4v:"' + video_file_url + vFileName + '.mp4", poster: "' + video_image_url + 'medium/' + $('#videoImage_' + i).val() + '"}';

                if (i != ($("#videoGallery li").length - 1)) {
                    videoDisplay += ',';
                }
            }
        }
        videoDisplay += ']';
		
        //console.log(videoDisplay);
        videoPlaylist = new jPlayerPlaylist({
            jPlayer: "#jquery_jplayer_1",
            cssSelectorAncestor: "#jp_container_1"
        }, eval(videoDisplay), {
            swfPath: $("#videoModuleUrl").val() + "jplayer/js",
            solution: 'html, flash',
            autoPlay: false,
            supplied: "webmv, mp4, m4v",
            wmode: "window",
            size: {
                width: "440px",
                height: "270px",
                cssClass: "jp-video-270p"
            }
        });
    }


    initPlayers();

    $("#videoGallery li").livequery('click', function (e) {
        var vtitle = $("#vtitle").val();
        var vdesc = $("#vdesc").val();
        var vvideographer = $("#vvideographer").val();
        var videoArray = $(this).find("a").attr('id').split('_');
        $('#videoCounter').val(videoArray[1]);
        videoPlaylist.select($('#videoCounter').val());
        videoPlaylist.pause($('#videoCounter').val());
        if ($('#videoTitle' + videoArray[1]).val() != '') {
            $("#playVideoTitle").html("<span class='vtitle'>" + vtitle + ": </span><span class='vvalue'>" + $('#videoTitle' + videoArray[1]).val() + "</span>");
        }
        if ($('#videoDesc' + videoArray[1]).val() != '') {
            $("#playVideoDesc").html("<span class='vtitle'>" + vdesc + ": </span><span class='vvalue'>" + $('#videoDesc' + videoArray[1]).val() + "</span>");
        }
        if ($('#videographerName' + videoArray[1]).val() != '') {
            $("#playVideographer").html("<span class='vtitle'>" + vvideographer + ": </span><span class='vvalue'>" + $('#videographerName' + videoArray[1]).val() + "</span>");
        }
        //$("#playVideoTitle").html($('#videoTitle'+videoArray[1]).val());
        //$("#playVideoDesc").html($('#videoDesc'+videoArray[1]).val()); 
        //$("#playVideographer").html($('#videographerName'+videoArray[1]).val());         

    });

    // START FOR ON CLICK PLAYER PREVIOUS
    $("#thumbPrev").livequery('click', function (e) {
	    var vtitle = $("#vtitle").val();
        var vdesc = $("#vdesc").val();
        var vvideographer = $("#vvideographer").val();
		
        if ($('#videoCounter').val() > 0) {
		 $('#videoCounter').val(parseInt($('#videoCounter').val()) - 1);
        }
		
        for (videoCnt = 0; videoCnt < $("#videoGallery li").length; videoCnt++) {
            if (videoCnt == $('#videoCounter').val()) {

                videoPlaylist.select($('#videoCounter').val());
                videoPlaylist.pause($('#videoCounter').val());
                
				//$("#playVideoTitle").html($( '#videoTitle' + $('#videoCounter').val()).val());
				$("#playVideoTitle").html("<span class='vtitle'>" + vtitle + ": </span><span class='vvalue'>" + $('#videoTitle' + $('#videoCounter').val()).val() + "</span>");
             
			    if($('#videoDesc' + $('#videoCounter').val()).val()!="" ){ 
 			      $("#playVideoDesc").html("<span class='vtitle'>" + vdesc + ": </span><span class='vvalue'>" + $('#videoDesc' + $('#videoCounter').val()).val() + "</span>");
				   //$("#playVideoDesc").html($('#videoDesc' + $('#videoCounter').val()).val());
				}
				if($('#videographerName' + $('#videoCounter').val()).val()!=""){
                  //$("#playVideographer").html($('#videographerName' + $('#videoCounter').val()).val());
				   $("#playVideographer").html("<span class='vtitle'>" + vvideographer + ": </span><span class='vvalue'>" + $('#videographerName' + $('#videoCounter').val()).val() + "</span>");
				}
            }
        }
        e.stopImmediatePropagation();

        // alert('End of code');
    });
    // END FOR ON CLICK PLAYER PREVIOUS   

    // START CODE FOR QUALITY
    $("#quality_720").livequery('click', function (e) {
        var qualityArray = $(this).attr('id').split("_");
        $("#quality").val(qualityArray[1]);
        $("#quality_720").addClass("active");
        $("#quality_360").removeClass("active");
        $("#quality_240").removeClass("active");
        initPlayers();
        videoPlaylist.select($('#videoCounter').val());
        videoPlaylist.pause($('#videoCounter').val());
    });

    $("#quality_360").livequery('click', function (e) {
        var qualityArray = $(this).attr('id').split("_");
        $("#quality").val(qualityArray[1]);
        $("#quality_360").addClass("active");
        $("#quality_240").removeClass("active");
        $("#quality_720").removeClass("active");
        initPlayers();
        videoPlaylist.select($('#videoCounter').val());
        videoPlaylist.pause($('#videoCounter').val());
    });

    $("#quality_240").livequery('click', function (e) {
        var qualityArray = $(this).attr('id').split("_");
        $("#quality").val(qualityArray[1]);
        $("#quality_240").addClass("active");
        $("#quality_360").removeClass("active");
        $("#quality_720").removeClass("active");
        initPlayers();
        videoPlaylist.select($('#videoCounter').val());
        videoPlaylist.pause($('#videoCounter').val());
    });
    // END CODE FOR QUALITY

    // START TO STOP CLICK SHOW IMAGE
    $(".jp-stop").livequery('click', function (e) {
        videoPlaylist.select($('#videoCounter').val());
        videoPlaylist.pause($('#videoCounter').val());
    });
    

    /* Audio Player */
    function initAudioPlayers() {
	
		var audio_url = $('#audio_url').val();
		
        var quality = $('#quality').val();
        var audio_file_url = audio_url + quality;
        var total_audio = parseInt($("#displayCount").val());

        var audioDisplay = '';
        audioDisplay += '[';
        for (a = 0; a < total_audio; a++) {

            audioDisplay += '{ oga: "' + audio_file_url + $('#audioFile_' + a).val() + '.ogg", mp3:"' + audio_file_url + $('#audioFile_' + a).val() + '.mp3"}';
            if (a != ((total_audio) - 1)) {
                audioDisplay += ',';
            }
        }
        audioDisplay += ']';

        audioPlaylist = new jPlayerPlaylist({
            jPlayer: "#jquery_jplayer_2",
            cssSelectorAncestor: "#jp_container_2"
        }, eval(audioDisplay), {
            swfPath: "js",
            supplied: "oga, mp3",
            wmode: "window"
        });
    }
    initAudioPlayers();

    $("#audioPrev").livequery('click', function (e) {
        var total_audio = parseInt($("#displayCount").val());
		var currentindex = parseInt($("#currentindex").val());
		if(currentindex == 0)
		{
		 var currentindex = parseInt($("#currentindex").val());
		}
		else
		{	
		 var currentindex = parseInt($("#currentindex").val()) - 1;
		}
		
        for (var k = 0; k < total_audio; k++) {
            if (k == audioPlaylist.current) {
                audioPlaylist.select(audioPlaylist.current);
                audioPlaylist.pause(audioPlaylist.current);
				showAudioDetail(currentindex);
				$.fn.carouselresize(currentindex);
            }
        }
       $("#currentindex").val(currentindex);
		  
    });

    $("#audioNext").livequery('click', function (e) {
        var total_audio = parseInt($("#displayCount").val());
        var total_audios = parseInt($("#displayCount").val()) - 1;
		 var currentindex = parseInt($("#currentindex").val());
		if(total_audios == currentindex)
		{
		 var currentindex = parseInt($("#currentindex").val());
		}
		else
		{	
		var currentindex = parseInt($("#currentindex").val()) + 1;
		}
        for (var m = 0; m < total_audio; m++) {
            if (m == currentindex) {
				
                audioPlaylist.select(audioPlaylist.current);
                audioPlaylist.pause(audioPlaylist.current);
				showAudioDetail(currentindex);
				$.fn.carouselresize(currentindex);
            }
        }
		$("#currentindex").val(currentindex);
		
        /* showAudioDetail(audioPlaylist.current);
        $.fn.carouselresize(audioPlaylist.current); */
    });

    $("#AudioList li").livequery('click', function (e) {
		

        var selected_id = $(this).find("a").attr('id').split('_');
        var id = selected_id[1];
		
        var total_audio = parseInt($("#displayCount").val());
        for (var m = 0; m < total_audio; m++) {
            if (m == id) {
                audioPlaylist.select(id);
				audioPlaylist.pause(id);
                audioPlaylist.current = parseInt(id);
            }
        }
        showAudioDetail(id);
        $.fn.carouselresize(id);
			$("#currentindex").val(id);
    });

    function showAudioDetail(id)
    {
	    $('div[class^="audio_detail_"]').each(function () {
            var selected_id = ($(this).attr('class')).split('_');
            var show_id = selected_id[2];

            if (id == show_id)
            {
                $(this).show();
            }
            else
            {
                $(this).hide();
            }
        });
    }

    $.fn.carouselresize = function (id) {

        $("#mycarousel_" + id + " img").each(function () {

            // $(this).load(function(){

            var containerWidth, containerHeight, containerRatio;
            var imageWidth, imageHeight, imageRatio;

            var $gaBG = $(this);
            // containerWidth = $(this).parent().parent().width();
            // containerHeight = $(this).parent().parent().height();  

            containerWidth = 550;
            containerHeight = 525;

            containerRatio = containerWidth / containerHeight;

            imageWidth = this.width;
            imageHeight = this.height;
            imageRatio = imageWidth / imageHeight;

            if (imageRatio > containerRatio) {
                $gaBG.width(containerWidth);
                $gaBG.height(containerWidth * (1 / imageRatio));
            }
            else if (imageRatio < containerRatio) {
                $gaBG.width(containerHeight * imageRatio);
                $gaBG.height(containerHeight);
            }
            else if (imageRatio == containerRatio) {
                if (imageWidth <= imageHeight) {
                    $gaBG.width(containerWidth);
                    $gaBG.height(containerWidth * (1 / imageRatio));
                }
                else {
                    $gaBG.width(containerHeight * imageRatio);
                    $gaBG.height(containerHeight);
                }
            }

            // })
        });

        $("#mycarousel_" + id).jcarousel({scroll: 1});

    }


    /* Audio player */


    /* ajax call on header tabs of other references */

    $(".tab_ajax").live("click", function () {
	
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_other_reference/" + currentActiveImgId;
        var activeTab = $(this).attr("data-bind");
        $.ajax({
            url: url,
            type: "POST",
            dataType: "text",
            data: {
                currentImgIndex: currentActiveImgId,
                activeTab: activeTab,
                jsstatus: 1
            },
            beforeSend: function () {
                $('.ajax_loader').show();
                $('.data_detail').fadeOut();
            },
            success: function (response) {
			//alert(response);
                $('#activeTab').val(activeTab);
                var htmlheaderfilter = $(response).filter("#refrence_header").find(".refrenceTab");
                var htmldetailsfilter = $(response).filter("#refrence_details").find(".refrence_details");
                $('.data_head').html(htmlheaderfilter);
                $('.data_detail').html(htmldetailsfilter).fadeIn();
                $(".ajax_loader").hide();


            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(thrownError);
            }
        }).done(function () {
            $.fn.bindJqueryLibrary();
        });

    });


    var ajaxFlag = false;
    function other_ref(currentActiveImgId, activeTab, jsstatus) {

        var base_url = $('#trans_url').val();
        var language_code = $('#language').val();
        var url = base_url + "/photos_other_reference/" + currentActiveImgId;
        $.ajax({
            url: url,
            type: "POST",
            dataType: "text",
            data: {
                currentImgIndex: currentActiveImgId,
                activeTab: activeTab,
                jsstatus: jsstatus
            },
            beforeSend: function () {
                ajaxFlag = true;
                $('.ajax_loader').show();
            },
            //contentType: 'application/x-www-form-urlencoded',
            success: function (response) {

                var htmlFiltered = $(response).filter("#refrence_header").find(".refrenceTab");
                var htmldetailsfilter = $(response).filter("#refrence_details").find(".refrence_details");
                $('.data_head').html(htmlFiltered).fadeIn();
                $('.data_detail').html(htmldetailsfilter).fadeIn();
                $(".ajax_loader").hide();
                ajaxFlag = false;

            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(thrownError);
            }
        }).done(function () {
            $.fn.bindJqueryLibrary();
        });
    }



    /* Load More data JS for all sections */

    $(window).scroll(function () {
        if (($(window).scrollTop() == ($(document).height() - $(window).height() - 1)) || ($(window).scrollTop() == ($(document).height() - $(window).height()))) {
            if (ajaxFlag == false) {
                var activetab = $("#activeTab").val();
                // check if no record found already exist no require to call ajax request                
                if (parseInt($("#totalCount").val()) > parseInt($("#displayCount").val())) {
                    if (activetab == 'photo') {
                        loadMorePhotos(activetab);
                    } else if (activetab == 'video') {
                        loadMoreVideos(activetab);
                    } else if (activetab == 'cartoon') {
                        loadMoreCartoons(activetab);
                    } else if (activetab == 'poster') {
                        loadMorePosters(activetab);
                    } else if (activetab == 'stamp') {
                        loadMoreStamps(activetab);
                    } else if (activetab == 'audio') {
                        loadMoreAudios(activetab);
                    } else if (activetab == 'tribute') {
                        loadMoreTributes(activetab);
                    } else if (activetab == 'cwmg') {
                        loadMoreCWMG(activetab);
                    } else if (activetab == 'variorum') {
                        loadMoreVariorums(activetab);
                    } else if (activetab == 'book') {
			loadMoreBook(activetab);
                    } else if (activetab == 'journalbygandhi') {
			loadMoreJournalgandhi(activetab);
                    } else if (activetab == 'journalbyother') {
			loadMoreJournalother(activetab);
                    } else if (activetab == 'othersection') {
			loadMoreothersection(activetab);
                    }
                }else if(activetab == 'othersection'){
                    var active_cat = $('#book-section-ref').val();
                    if (parseInt($("#totalCount_"+active_cat).val()) > parseInt($("#displayCount_"+active_cat).val())) {
                        
                        loadMoreothersection(activetab,active_cat);
                    }    
                }else{
                    
                }
                
            }
        }
    });


    function loadMoreVideos(activeTab) {

        var last_id = $('#videoId').val();
        var video_key = $('#video_key').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;

        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab,
                    video_key: video_key
                    
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 3);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#videoGallery').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                $.fn.bindJqueryLibrary();
            });
        }
    }

    function loadMoreCartoons(activeTab) {
        var last_id = $('#cartoonId').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 3);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#CartoonGallery').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                $.fn.bindJqueryLibrary();
            });
        }
    }

    function loadMoreAudios(activeTab) {
        var last_id = $('#audioId').val();
        var base_url = $('#trans_url').val();
		var audio_key = $('#audio_key').val();
        var currentActiveImgId = $('#currentImgId').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab,
					audio_key: audio_key
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 3);
                    var totalCount = (parseInt($("#totalCount").val()));
					if(totalCount < newdisplayCount)
					{
						newdisplayCount = totalCount;
					}
                    $('#displayCount').val(newdisplayCount);
					//$('ul#AudioList').append(response);
					//data = $('#audio_detail_loadmore_'+last_id).html();
					var arr = response.split('[[%%HTMLSPLIT%%]]');
					$('ul#AudioList').append(arr[0]);
				    $('#audio_detail').append(arr[1]);
					
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                $.fn.bindJqueryLibrary();
            });
        }
    }

    function loadMorePosters(activeTab) {
        var last_id = $('#posterId').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 3);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#wcagPosterList').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                $.fn.bindJqueryLibrary();
            });
        }
    }

    function loadMoreStamps(activeTab) {
        var last_id = $('#stampId').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 4);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#stamplist').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                $.fn.bindJqueryLibrary();
            });
        }
    }

    function loadMoreTributes(activeTab) {
        var last_id = $('#tributeId').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 3);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#wcagTributeList').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                $.fn.bindJqueryLibrary();
            });
        }
    }

    function loadMoreCWMG(activeTab) {
        var last_id = $('#cwmgId').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 3);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#CwmgList').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                $.fn.bindJqueryLibrary();
            });
        }
    }

    function loadMoreVariorums(activeTab) {
        var last_id = $('#variorumId').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 3);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#VariorumList').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                //$.fn.bindJqueryLibrary();
            });
        }
    }
	
	function loadMoreBook(activeTab) {
        var last_id = $('#bookid').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 3);
                    $('#displayCount').val(newdisplayCount);
                    $('ul.listing').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                //$.fn.bindJqueryLibrary();
            });
        }
    }
	
	function loadMoreJournalgandhi(activeTab) {
        var last_id = $('#journal_id').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 4);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#leftPanelCheckboxListing').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                //$.fn.bindJqueryLibrary();
            });
        }
    }
	function loadMoreJournalother(activeTab) {
	
        var last_id = $('#journal_id').val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
	            $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    var newdisplayCount = (parseInt($("#displayCount").val()) + 4);
                    $('#displayCount').val(newdisplayCount);
                    $('ul#leftPanelCheckboxListing').append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                //$.fn.bindJqueryLibrary();
            });
        }
    }
	
    function loadMoreothersection(activeTab,active_cat) {
        
        
        var last_id = $('#other_section_'+active_cat).val();
        var currentActiveImgId = $('#currentImgId').val();
        var base_url = $('#trans_url').val();
        var url = base_url + "/photos_reference/" + currentActiveImgId;
        if (last_id > 0) {
	        $.ajax({
                url: url,
                type: "POST",
                dataType: "text",
                data: {
                    last_id: last_id,
                    photo_id: currentActiveImgId,
                    activeTab: activeTab,
                    active_cat:active_cat,
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.ajax_loader').show();
                },
                success: function (response) {
                    
                    var newdisplayCount = (parseInt($("#displayCount_"+active_cat).val()) + 3);
                    $("#displayCount_"+active_cat).val(newdisplayCount);
                    $('ul#otherbookslisting_'+active_cat).append(response);
                    $(".ajax_loader").hide();
                    ajaxFlag = false;
                }
            }).done(function () {
                //$.fn.bindJqueryLibrary();
            });
        }
    }

});

function nextPlayer()
{
    var totalCount = parseInt($("#totalCount").val()) - 1;
    var displayCount = parseInt(jQuery('#displayCount').val()) - 1;
	var videcounter = parseInt(jQuery('#videoCounter').val());
	if(displayCount == videcounter)

    {
        jQuery('#videoCounter').val(parseInt(jQuery('#videoCounter').val()));
    }
    else if(totalCount == videcounter)
    {
        jQuery('#videoCounter').val(parseInt(jQuery('#videoCounter').val()));
    }
	else
    {
        jQuery('#videoCounter').val(parseInt(jQuery('#videoCounter').val()) + 1);
    }
    var vtitle = $("#vtitle").val();
    var vdesc = $("#vdesc").val();
    var vvideographer = $("#vvideographer").val();
    
    for (videoCnt = 0; videoCnt < jQuery("#videoGallery li").length; videoCnt++) {
        if (videoCnt == jQuery('#videoCounter').val()) {
            videoPlaylist.select(jQuery('#videoCounter').val());
            videoPlaylist.pause(jQuery('#videoCounter').val());
			if(jQuery('#videoTitle' + jQuery('#videoCounter').val()).val()!=""){
				//jQuery("#playVideoTitle").html(jQuery('#videoTitle' + jQuery('#videoCounter').val()).val());
				$("#playVideoTitle").html("<span class='vtitle'>" + vtitle + ": </span><span class='vvalue'>" + jQuery('#videoTitle' + jQuery('#videoCounter').val()).val() + "</span>");
			}
			if(jQuery('#videoDesc' + jQuery('#videoCounter').val()).val()!="" ){
			
             //jQuery("#playVideoDesc").html(jQuery('#videoDesc' + jQuery('#videoCounter').val()).val());
			  $("#playVideoDesc").html("<span class='vtitle'>" + vdesc + ": </span><span class='vvalue'>" + jQuery('#videoDesc' + jQuery('#videoCounter').val()).val() + "</span>");
			}
			if(jQuery('#videographerName' + jQuery('#videoCounter').val()).val()!=""){
            //jQuery("#playVideographer").html(jQuery('#videographerName' + jQuery('#videoCounter').val()).val());
			 $("#playVideographer").html("<span class='vtitle'>" + vvideographer + ": </span><span class='vvalue'>" + jQuery('#videographerName' + jQuery('#videoCounter').val()).val() + "</span>");
			}
        }
    }
}