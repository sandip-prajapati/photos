function delete_photocategory(cid,langCode)
{
    var flag = confirm("Are you really sure, you want to delete this photo category?");
    if(flag == true)    
    {
       document.frmGHPphotoCategory.del_id.value = cid;
       document.frmGHPphotoCategory.lang_code.value = langCode;
       document.frmGHPphotoCategory.submit();
    }
}
function deleteall_photocategory(val)
{
    var basepathurl = document.getElementById("baseurlpath").value;
    var adminRenamePath = document.getElementById("adminRenamePath").value; 
    var langCode = document.getElementById("lang_code").value;      
    var checked_num = jQuery('input[name="categoryselect[]"]:checked').length; //Added by Maya for multiple delete
    if(checked_num === 0)
    {
        alert("Please select record(s)");return false;
    }    
    if(val == "Deleteall")
    { 
        var flag = confirm("Are you really sure, you want to delete this photo category?");
        if(flag === true){        
            document.frmGHPphotoCategory.lang_code.value = langCode;
            document.frmGHPphotoCategory.action =basepathurl+"/"+adminRenamePath+"/photo_category/deleteall" ;
            document.frmGHPphotoCategory.submit();
        }
    }
}
function toggleCheckboxes() {
   

  	var inputlist = document.getElementsByTagName("input");        
  	for (i = 0; i < inputlist.length; i++) {
            
	if ( inputlist[i].getAttribute("type") == 'checkbox' ) {	// look only at input elements that are checkboxes
			if (inputlist[i].checked)
                        {
                            inputlist[i].checked = false;
                            document.getElementById("photocategorycheckall").checked=false;
                                
                          }
			else
                          {
						 
                            inputlist[i].checked = true;
                            document.getElementById("photocategorycheckall").checked=true;
                        }
	}
}
}

