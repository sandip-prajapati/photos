jQuery(function($) {
    
    $("#edit-language").change(function () {
        window.location.href = $('#baseUrl').val()+$(this).val()+'/'+$('#photoId').val();
    });    
    
    var imagePath = $("#imagepath").val();
	//alert(imagePath);
    $("#edit-photo-date").datepick({
        showOnFocus: false, 
        showTrigger: "<img src='"+imagePath+"calendar.gif' border='0' style='margin:0 0 0 5px;'/>",
        yearRange: '1869:1948',
        dateFormat: 'yyyy-mm-dd',
        defaultDate: '1869-01-01'
    });
});