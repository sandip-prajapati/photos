 //jQuery(document).ready(function(){
 jQuery(function ($) {
    var counter = 0;
    var mouseX = 0;
    var mouseY = 0;
    var base_url = $('#baseUrlpath').val();
	var baseURL = $('#baseUrl').val();
	// mouseover the taglist 
	$('#taglist').on( 'mouseover', 'li', function( ) {
      id = $(this).attr("id");
      $('#view_' + id).css({ opacity: 1.0 });
    }).on( 'mouseout', 'li', function( ) {
        $('#view_' + id).css({ opacity: 1.0 });
    });
	
	// mouseover the tagboxes that is already there but opacity is 0.
	$( '#tagbox' ).on( 'mouseover', '.tagview', function( ) {
		var pos = $( this ).position();
		$(this).css({ opacity: 1.0 }); // div appears when opacity is set to 1.
	}).on( 'mouseout', '.tagview', function( ) {
		$(this).css({ opacity: 1.0 }); // hide the div by setting opacity to 0.
	});
    
	
	
	// load the tags for the image when page loads.
    var img = $('#imgtag').find( 'img' );
	var id = $( img ).attr( 'id' );
	//console.log(id);
	//alert(id);
	viewtag( id ); // view all tags available on page load
    
    function viewtag( pic_id )
    {
	 $('.ad-loader').show();
	  // get the tag list with action remove and tag boxes and place it on the image.
	  //$path = "http://localhost/ghp-drupal/trunk/backend/taglist";
	  $path = baseURL + '/taglist';
	  $.post( $path ,  "pic_id=" + pic_id + "&imgtype=normal", function( data ) {
	   $('.ad-loader').hide();
	  	$('#taglist ol').html(data.lists);
		$('#tagbox').html(data.boxes);
                $('#copyright_content').html('');
                $('#copyright_content').html(data.copyright);
                 
	  }, "json");
	
    }
	
	
    
  });