 //jQuery(document).ready(function(){
 jQuery(function ($) {
    var counter = 0;
    var mouseX = 0;
    var mouseY = 0;
    var base_url = $('#baseUrlpath').val();
	//normal case
    $("#imgtags img").click(function(e) { // make sure the image is click
      var imgtags = $(this).parent(); // get the div to append the tagging list
      mouseX = ( e.pageX - $(imgtags).offset().left ) - 50; // x and y axis
      mouseY = ( e.pageY - $(imgtags).offset().top ) - 50;
      $( '#tagit' ).remove( ); // remove any tagit div first
      $( imgtags ).append( '<div id="tagit"><div class="box"></div><div class="name"><div class="text"></div><input type="text" placeholder="Type any name or tag" name="txtname" id="tagname" /><input type="button" name="btnsave" value="Save" id="btnsave" /><input type="button" name="btncancel" value="Cancel" id="btncancel" /></div></div>' );
      $( '#tagit' ).css({ top:mouseY, left:mouseX });
      
      $('#tagname').focus();
    });
	//large case
	$("#imgtaglarge img").click(function(e) { 
	// make sure the image is click
      var imgtaglarge = $(this).parent(); // get the div to append the tagging list
      mouseX = ( e.pageX - $(imgtaglarge).offset().left ) - 50; // x and y axis
      mouseY = ( e.pageY - $(imgtaglarge).offset().top ) - 50;
      $( '#tagitlarge' ).remove( ); // remove any tagit div first
      $( imgtaglarge ).append( '<div id="tagitlarge"><div class="box"></div><div class="name"><div class="text"></div><input type="text" placeholder="Type any name or tag" name="txtname" id="tagnamelarge" /><input type="button" name="btnsave" value="Save" id="btnsavelarge" /><input type="button" name="btncancel" value="Cancel" id="btncancellarge" /></div></div>' );
      $( '#tagitlarge' ).css({ top:mouseY, left:mouseX });
      
      $('#tagnamelarge').focus();
    });
    //normal case
	// Save button click - save tags
    $( document ).on( 'click',  '#tagit #btnsave', function(){
	$('.ad-loaderback').show();
      name = $('#tagname').val();
		var img = $('#imgtags').find( 'img' );
		var id = $( img ).attr( 'id' );
		var type = $( img ).attr( 'type' );
		
      $.ajax({
        type: "POST",
		url : $("#baseUrlpath").val() + 'savetag',
        //url: "savetag.php", 
        data: "pic_id=" + id + "&name=" + name + "&pic_x=" + mouseX + "&pic_y=" + mouseY + "&imgtype=" + type + "&type=insert",
        cache: true, 
        success: function(data){
		  $('.ad-loaderback').hide();
          viewtag( id );
          $('#tagit').fadeOut();
        }
      });
      
    });
	//normal case
	// load the tags for the image when page loads.
    var img = $('#imgtags').find( 'img' );
	var id = $( img ).attr( 'id' );
	var imgtype = $( img ).attr( 'type' );
	viewtag( id ); // view all tags available on page load
    function viewtag( pic_id )
    {
	$('.ad-loaderback').show();
      // get the tag list with action remove and tag boxes and place it on the image.
	  //$.post( "taglist.php" ,  "pic_id=" + pic_id, function( data ) {
	  
	  $.post( $("#baseUrlpath").val() + 'taglist' ,  "pic_id=" + pic_id +"&imgtype=normal", function( data ) {
	  $('.ad-loaderback').hide();
		$('#taglist ol').html(data.lists);
		$('#tagbox').html(data.boxes);
		}, "json");
	}
	
	// large case
	// Save button click - save tags large case
    $( document ).on( 'click',  '#tagitlarge #btnsavelarge', function(){
	
	$('.ad-loaderbacks').show();
      name = $('#tagnamelarge').val();
		var img = $('#imgtaglarge').find( 'img' );
		var id = $( img ).attr( 'id' );
		var type = $( img ).attr( 'type' );
		
      $.ajax({
        type: "POST",
		url : $("#baseUrlpath").val() + 'savetag',
        //url: "savetag.php", 
        data: "pic_id=" + id + "&name=" + name + "&pic_x=" + mouseX + "&pic_y=" + mouseY + "&imgtype=" + type + "&type=insert",
        cache: true, 
        success: function(data){
		  $('.ad-loaderbacks').hide();
          viewtaglarge( id );
          $('#tagitlarge').fadeOut();
        }
      });
      
    });
    
	// Cancel the tag box.
    $( document ).on( 'click', '#tagit #btncancel', function() {
      $('#tagit').fadeOut();
    });
	
	// Cancel the tag box large.
    $( document ).on( 'click', '#tagitlarge #btncancellarge', function() {
	$('#tagitlarge').fadeOut();
    });
    
	// mouseover the taglist 
	$('#taglist').on( 'mouseover', 'li', function( ) {
      id = $(this).attr("id");
      $('#view_' + id).css({ opacity: 1.0 });
    }).on( 'mouseout', 'li', function( ) {
        $('#view_' + id).css({ opacity: 1.0 });
    });
	// mouseover the taglist large
	$('#taglistlarge').on( 'mouseover', 'li', function( ) {
      id = $(this).attr("id");
      $('#view_' + id).css({ opacity: 1.0 });
    }).on( 'mouseout', 'li', function( ) {
        $('#view_' + id).css({ opacity: 1.0 });
    });
	
	// mouseover the tagboxes that is already there but opacity is 0.
	$( '#tagbox' ).on( 'mouseover', '.tagview', function( ) {
		var pos = $( this ).position();
		$(this).css({ opacity: 1.0 }); // div appears when opacity is set to 1.
	}).on( 'mouseout', '.tagview', function( ) {
		$(this).css({ opacity: 1.0 }); // hide the div by setting opacity to 0.
	});
	
	
	// mouseover the tagboxes that is already there but opacity is 0. large case
	$( '#tagboxlarge' ).on( 'mouseover', '.tagviewlarge', function( ) {
		var pos = $( this ).position();
		$(this).css({ opacity: 1.0 }); // div appears when opacity is set to 1.
	}).on( 'mouseout', '.tagviewlarge', function( ) {
		$(this).css({ opacity: 1.0 }); // hide the div by setting opacity to 0.
	});
	
    //normal case
	// Remove tags.
    $( '#taglist' ).on('click', '.remove', function() {
	$('.ad-loaderback').show();
      id = $(this).parent().attr("id");
      imgtype = $(this).parent().attr("imgtype");
      // Remove the tag
	  $.ajax({
        type: "POST", 
        //url: "savetag.php", 
		url : $("#baseUrlpath").val() + 'savetag',
        data: "tag_id=" + id + "&imgtype=" + imgtype + "&type=remove",
        success: function(data) {
			$('.ad-loaderback').hide();
			var img = $('#imgtags').find( 'img' );
			var id = $( img ).attr( 'id' );
			//get tags if present
			viewtag( id );
        }
      });
    });
	
	
	//large case
	// Remove tags larege.
    $( '#taglistlarge' ).on('click', '.remove', function() {
	$('.ad-loaderbacks').show();
      id = $(this).parent().attr("id");
      imgtype = $(this).parent().attr("imgtype");
      // Remove the tag
	  $.ajax({
        type: "POST", 
        //url: "savetag.php", 
		url : $("#baseUrlpath").val() + 'savetag',
        data: "tag_id=" + id + "&imgtype=" + imgtype + "&type=remove",
        success: function(data) {
			$('.ad-loaderbacks').hide();
			var img = $('#imgtaglarge').find( 'img' );
			var id = $( img ).attr( 'id' );
			//get tags if present
			viewtaglarge( id );
        }
      });
    });
	
	
	
	// larges case
	// load the tags for the image when page loads.
    var img = $('#imgtaglarge').find( 'img' );
	var id = $( img ).attr( 'id' );
	var imgtype = $( img ).attr( 'type' );
	viewtaglarge( id ); // view all tags available on page load
    function viewtaglarge( pic_id )
    {
	$('.ad-loaderbacks').show();
      // get the tag list with action remove and tag boxes and place it on the image.
	  //$.post( "taglist.php" ,  "pic_id=" + pic_id, function( data ) {
	  
	  $.post( $("#baseUrlpath").val() + 'taglist' ,  "pic_id=" + pic_id + "&imgtype=large", function( datalarge ) {
	  $('.ad-loaderbacks').hide();
		 $('#taglistlarge ol').html(datalarge.listslarge);
		 $('#tagboxlarge').html(datalarge.boxeslarge);
	  }, "json");
	
    }
	
    
    
  });