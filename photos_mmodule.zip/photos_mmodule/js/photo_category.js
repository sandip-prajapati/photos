function delete_category(cid,langCode)
{
    var flag = confirm("Are you really sure, you want to delete this category?");
    if(flag == true)    
    {
       document.frmGHPCategory.del_id.value = cid;
       document.frmGHPCategory.lang_code.value = langCode;
       document.frmGHPCategory.submit();
    }    
}
