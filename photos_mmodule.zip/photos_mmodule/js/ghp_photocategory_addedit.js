jQuery(function($) {
    jQuery("#edit-language").change(function () {
        
        if($('#photocategoryId').val() != undefined){
            window.location.href = $('#baseUrl').val()+$(this).val()+'/'+$('#photocategoryId').val();
         }
    });
});