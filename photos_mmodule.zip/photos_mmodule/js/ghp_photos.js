jQuery(document).ready(function ($) {


    // START SEARCH WCAG
    //$("#photoThumbSearchBlock").show();
    //$("#photoThumbSearchBlockPhp").hide();
    
    $("input[name='Deselect']").prop("type", "button");

    $("#updates").show();
    $("#updates1").hide();

    $(".volumelistcls").uniform();

    var phototitle = $('#phototitle').val();
    var photodesc = $('#photodesc').val();
    var photoplace = $('#photoplace').val();
    var photopeople = $('#photopeople').val();
    var photosource = $('#photosource').val();
    var norecord = $('#norecord').val();
    var baseUrl = $('#baseUrl').val();
    // STOP SEARCH WCAG    
    $('.productImage img').livequery('click', function (e) {
        var currentActiveImgId = $(this).attr("id");
        $("a[rel=example_group]").fancybox({
            'overlayShow': 'false',
            'transitionIn': 'elastic',
            'transitionOut': 'elastic',
            'titlePosition': 'inside',
            'titleFormat'		: formatTitle
        });
        viewtag(currentActiveImgId);
        function viewtag(pic_id)
        {
            $('.ad-loader').show();
            $path = baseUrl + '/taglist';
            $.post($path, "pic_id=" + pic_id + "&imgtype=large", function (datalarge) {
                $('.ad-loader').hide();
                //$('#taglist ol').html(data.lists);
                $('#tagbox1').html(datalarge.boxeslarge);
            }, "json");

        }

    });


    /*Deselect checkbox form download zip*/
    $('#Deselect').click(function () {
        $('.photoZip').each(function () { //loop through each checkbox
            this.checked = false; //deselect all checkboxes with class "photoZip"                      
        });
        $('.icheckbox_square-grey').removeClass('checked');
    });


//Fancy check box of thumb view
    $('input').iCheck({
        checkboxClass: 'icheckbox_square-grey',
        //radioClass: 'iradio_square-red',
        increaseArea: '20%' // optional
    });


    function formatTitle(title, currentArray, currentIndex, currentOpts) {
        var photoDesc = '';

        $(".message_box").each(function () {
            if ($(this).find('.pcounter').val() == currentIndex) {
                photoDesc = '<div id="tip7-title"><span><a href="javascript:;" onclick="$.fancybox.close();"></a></span>';

                photoDesc += '<div class="gallery_inner1">';
               /* if ($(this).find('.phototitle').val() != '')
                {
                    photoDesc += '<h3>' + phototitle + ': <span class="phototitle">' + $(this).find('.phototitle').val() + '</span></h3>';
                }*/

                /*if($(this).find('.photoaltertext').val() != '')
                 {
                 photoDesc += '<h3>'+photoaltertext+': <span class="photoaltertext">'+$(this).find('.photoaltertext').val()+'</span></h3>';
                 }*/

                if ($(this).find('.photodesc').val() != '')
                {
                    photoDesc += '<h3>' + photodesc + ': <span class="photodesc">' + $(this).find('.photodesc').val() + '</span></h3>';
                }

                if ($(this).find('.photoplace').val() != '')
                {
                    photoDesc += '<h3>' + photoplace + ': <span class="photodesc">' + $(this).find('.photoplace').val() + '</span></h3>';
                }

                if ($(this).find('.photopeople').val() != '')
                {
                    photoDesc += '<h3>' + photopeople + ': <span class="photodesc">' + $(this).find('.photopeople').val() + '</span></h3>';
                }
                if ($(this).find('.photosource').val() != '')
                {
                    photoDesc += '<h3>' + photosource + ': <span class="photodesc">' + $(this).find('.photosource').val() + '</span></h3>';
                }
                photoDesc += '</div>';

//<b>' + title + '</b>' +  ($(this).find('.photoplace').val() && $(this).find('.photoplace').val().length ?  '<br/>Place : '+$(this).find('.photoplace').val()  : '' ) +  ($(this).find('.photopeople').val() && $(this).find('.photopeople').val().length ? '<br/>People : ' +$(this).find('.photopeople').val() : '' )+'</div>';
            }
        });
        return photoDesc;
    }

    var ajaxFlag = false;
    function last_msg_funtion() {

        var last_msg_id = $('#photo_id').val();
        var languagevalue = $('#languagevalue').val();

        //return false;
        var defaultlanguage = $('#defaultlanguage').val();
        var basepathvalue = $('#basepathvaluethumb').val();
        var modulepathval = $('#modulepathval').val();
        var selected_checkbox = $('#selected_checkbox').val();
        var photoDisplayCounter = $('#photoDisplayCounter').val();

        // GET GLOBAL SEARCH KEYWORD FOR AJAX RESULT
        var global_search_keyword = $("#global_search_keyword").val();
        var photo_search_keyword = $("#photoKeyword1").val();
        var photo_category = $("#photo_category").val();

        var last_paging_number = $("#photo_paging_number").val();

        var endId = $("#end").attr('id');

        if (endId != 'end') {
            if (languagevalue == defaultlanguage) {
                var url = basepathvalue + "/photos_thumbajaxview";
            } else {
                var url = basepathvalue + "/" + languagevalue + "/photos_thumbajaxview";
            }
            //alert(url);
            //return false;
            jQuery.ajax({
                type: "POST",
                url: url,
                dataType: 'json',
                data: {
                    photoDisplayCounter: photoDisplayCounter,
                    lastmsg: last_msg_id,
                    languagevalue: languagevalue,
                    selected_checkbox: selected_checkbox,
                    global_search_keyword: global_search_keyword,
                    photo_category: photo_category,
                    photo_search_keyword: photo_search_keyword,
                    last_paging_number: last_paging_number
                },
                beforeSend: function () {
                    ajaxFlag = true;
                    $('.facebook_style').show();
                },
                success: function (data) {

                    //if(data != ''){
                    var displayCounter = photoDisplayCounter;
                    var lastphotoid = '';
                    var bindData = '';
                    var baseUrl = '';
                    var photo_medium_url = $("#photo_medium_url").val();
                    var photo_url = $("#photo_url").val();
                    var baseUrl = $("#baseUrl").val();

                    if (data['totalResultCount'] > 0)
                    {
                        var addCounter = parseInt($('#currentcount').html()) + parseInt(data['totalResultCount']);
                        $('#currentcount').html(addCounter);
                        for (var i = 0; i < data['totalResultCount']; i++)
                        {
                            var lastphotoid = data['result_display_data'][i].photo_id;
							var midiumImageUrl = photo_medium_url + data['result_display_data'][i].photo_filename;
                            var ImageUrl = photo_url + "print/8x11/" + data['result_display_data'][i].photo_filename;
							
                            var titletext;
                            var altertext;
                            /*   var title = htmlentities($.fn.stripslashes( data['result_display_data'][i].photo_title,"ENT_QUOTES") );
                             alert(title);
                             var altertext = htmlentities($.fn.stripslashes( data['result_display_data'][i].photo_alter_text,"ENT_QUOTES") ); */

                            //For alter text
                            if (data['result_display_data'][i].photo_alter_text != '')
                            {
                                altertext = data['result_display_data'][i].photo_alter_text;
                            }
                            else
                            {
                                altertext = data['result_display_data'][i].photo_filename;
                            }

                            if (data['result_display_data'][i].photo_title != '')
                            {
                                titletext = data['result_display_data'][i].photo_title;
                            }
                            else
                            {
                                titletext = data['result_display_data'][i].photo_filename;
                            }
                            var checkbox = '';
														var fileSize = data['result_display_data'][i].filesize;
                           /* if (data['result_display_data'][i].flag == 1) {
                                checkbox = "<input type='checkbox' id='photozip_" + lastphotoid + "' name='photozip[]' class='photoZip' value='" + lastphotoid + "'>";
                            }*/
														
														if(fileSize != ''){
																checkbox = "<input type='checkbox' id='photozip_" + lastphotoid + "' name='photozip[]' class='photoZip' value='" + lastphotoid + "'>";
														}
														
                            var description = htmlentities($.fn.stripslashes(data['result_display_data'][i].photo_description, "ENT_QUOTES"));

                            var photoPlace = $.fn.stripslashes(data['result_display_data'][i].photo_place);
                            var photoPeople = $.fn.stripslashes(data['result_display_data'][i].photo_people);
                            var photoSource = $.fn.stripslashes(data['result_display_data'][i].photo_source);

														
														
                            bindData += "<li id='photothumb_" + lastphotoid + "' class='message_box'>" + checkbox + "<a rel='example_group' href='" + ImageUrl + "' img_id='"+ lastphotoid +"'  class='productImage pop' title='" + titletext + "'><img  id='" + lastphotoid + "'  src='" + midiumImageUrl + "' alt='" + altertext + "' title='" + titletext + "' img_id='"+ lastphotoid +"'  height='135' width='129' /></a>";
														
														if(fileSize != ''){
																bindData += '<div class = "file_size">( File Size : '+fileSize+' KB )<div>';
														}
														
														bindData += "<input type='hidden' name='baseUrl' id='baseUrl' value='" + baseUrl + "' /><input type='hidden' class='pcounter' name='photocounter_" + displayCounter + "' id= 'photocounter_" + displayCounter + "' value='" + displayCounter + "' /><input type='hidden' class='phototitle' name='phototitle_" + lastphotoid + "' id= 'phototitle_" + lastphotoid + "' value='" + titletext + "' /><input type='hidden' class='photoplace' name='photoplace_" + lastphotoid + "' id= 'photoplace_" + lastphotoid + "' value='" + photoPlace + "' /><input type='hidden' class='photopeople' name='photopeople_" + lastphotoid + "' id= 'photopeople_" + lastphotoid + "' value='" + photoPeople + "' /><input type='hidden' class='photosource' name='photosource_" + lastphotoid + "' id= 'photosource_" + lastphotoid + "' value='" + photoSource + "' />";

                            bindData += '<input type="hidden" class="photodesc" name="photodesc_' + lastphotoid + '" id= "photodesc_' + lastphotoid + '" value="' + description + '" />';
                            displayCounter++;
                        }
                    }
                    if (data['totalResultCount'] > 0) {
                        bindData += '';
                    } else {
                        bindData += '<div class="galleryCon" style="background: none; border: none; min-height: 36px; text-align: center; font-weight: bold;">' + norecord + '</div><div id="end"></div>';
                    }

                    $("ul#updates").append(bindData);
                    $(".facebook_style").hide();
                    ajaxFlag = false;
                    $('#photo_id').val(lastphotoid);
                    $('#photoDisplayCounter').val(displayCounter);
                    $("#photo_paging_number").val(parseInt(last_paging_number) + 15);
                    $('input').iCheck({
                        checkboxClass: 'icheckbox_square-grey',
                        //radioClass: 'iradio_square-red',
                        increaseArea: '20%' // optional
                    });
                    //}
                }
            }).done(function () {
                // START CALL FANCYBOX
                $("a[rel=example_group]").fancybox({
                    'overlayShow': 'false',
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'titlePosition': 'inside',
                    'titleFormat': formatTitle
                });
                // STOP CALL FANCYBOX 
            });
        }
    }

    $(window).scroll(function () {
        if (($(window).scrollTop() == ($(document).height() - $(window).height() - 1)) || ($(window).scrollTop() == ($(document).height() - $(window).height()))) {
            if (ajaxFlag == false) {
                // check if no record found already exist no require to call ajax request
                var NoItem = $('ul#updates li:contains("No Record Found.")');
                //var NoItem2 = $('ul#updates li:contains("'+norecord+'")'); 
                //if(NoItem.length == 0 && NoItem2.length) {
                if (NoItem.length == 0) {
                    last_msg_funtion();
                }
            }
        }
    });

    $.fn.stripslashes = function (str) {
        str = str.replace(/\\'/g, '\'');
        str = str.replace(/\\"/g, '"');
        str = str.replace(/\\\\/g, '\\');
        str = str.replace(/\\0/g, '\0');
        return str;
    };

    // START PAGING WCAG
    $("#wcagpaging").hide();
// STOP PAGING WCAG      

    /*Photo Download Zip*/
    /*	 $('#downloadZip').click(function() {
     var photoarray = [];
     var baseURL = $('#basepathvaluethumb').val();
     var count = ($('.photoZip:checked').length);
     if(count > 10)
     {
     alert("You can select only 10 check boxes for download zip.");
     return false;method='post'
     }
     else
     {
     $('.photoZip:checked').each(function(){
     var link = $(this).val();
     var image = link.split('/');
     var photo_name = image[10];
     //alert(photo_name);
     photoarray.push(photo_name);
     });
     }
     photoarray = photoarray.join(',');
     location.href = baseURL+'/photoDownloadZip/'+b64.encode(photoarray);
     return false;
     });*/

});


