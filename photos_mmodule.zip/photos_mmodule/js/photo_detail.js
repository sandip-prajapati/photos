jQuery(document).ready(function($) {

    $(".wcagPhotoList").hide();
    $(".PhotoList").show();
    $(".wcagVideoList").hide();
    $(".VideoList").show();
    $("#langDrop").show();
    $("#wcaglangDrop").hide();
    $("#wcagAudioList").hide();
    $("#AudioList").show();

    var phototitle = $('#phototitle').val();

    $("a[rel=example_group]").fancybox({
        'transitionIn': 'elastic',
        'transitionOut': 'fade',
        'titlePosition': 'inside',
        'titleFormat': formatTitle
    });

    $("a[rel=gallery_cartoon_group]").fancybox({
        'transitionIn': 'elastic',
        'transitionOut': 'fade',
        'titlePosition': 'inside',
        'titleFormat': formatCartoonTitle
    });
			
	
    function formatTitle(title, currentArray, currentIndex, currentOpts) {
        var photoDesc = '';

        $(".message_box").each(function() {
            if ($(this).find('.pcounter').val() == currentIndex) {
                photoDesc = '<div id="tip7-title"><span><a href="javascript:;" onclick="$.fancybox.close();"></a></span>';

                photoDesc += '<div class="gallery_inner1">';
                if ($(this).find('.phototitle').val() != '')
                {
                    photoDesc += '<h3>' + phototitle + ': <span class="phototitle">' + $(this).find('.phototitle').val() + '</span></h3>';
                }

                if ($(this).find('.photodesc').val() != '')
                {
                    photoDesc += '<h3>' + photodesc + ': <span class="photodesc">' + $(this).find('.photodesc').val() + '</span></h3>';
                }

                if ($(this).find('.photoplace').val() != '')
                {
                    photoDesc += '<h3>' + photoplace + ': <span class="photodesc">' + $(this).find('.photoplace').val() + '</span></h3>';
                }

                if ($(this).find('.photopeople').val() != '')
                {
                    photoDesc += '<h3>' + photopeople + ': <span class="photodesc">' + $(this).find('.photopeople').val() + '</span></h3>';
                }
                if ($(this).find('.photosource').val() != '')
                {
                    photoDesc += '<h3>' + photosource + ': <span class="photodesc">' + $(this).find('.photosource').val() + '</span></h3>';
                }
                photoDesc += '</div>';
            }
        });
        return photoDesc;
    }


/*
    function formatCartoonTitle() {

        var cartoonDesc = '';
        cartoonDesc = '<div class="gallery_inner1">';
        if ($(this).attr('title') != '')
        {
            cartoonDesc += '<h3>' + $('#phototitle').val() + ': <span class="phototitle">' + $(this).attr('title') + '</span></h3>';
        }
        cartoonDesc += '</div>';
        return cartoonDesc;
    }

  */  

    // On Scroll load photo and videos
/*
    var ajaxFlag = false;
    $(window).scroll(function() {
        if (($(window).scrollTop() == ($(document).height() - $(window).height() - 1)) || ($(window).scrollTop() == ($(document).height() - $(window).height()))) {
            if (ajaxFlag == false) {
                // check if no record found already exist no require to call ajax request                
                if (parseInt($("#totalCount").val()) > parseInt($("#displayCount").val())) {
                    var activetab = $("#activeTab").val();
                    if (activetab == 'photo') {
                        loadMorePhotos(activetab);
                    } else if (activetab == 'video') {
                        loadMoreVideos(activetab);
                    } else if (activetab == 'cartoon') {
                        loadMoreCartoons(activetab);
                    } else if (activetab == 'poster') {
                        loadMorePosters(activetab);
                    } else if (activetab == 'stamp') {
                        loadMoreStamps(activetab);
                    } else if (activetab == 'audio') {
                        loadMoreAudios(activetab);
                    } else if (activetab == 'tribute') {
                        loadMoreTributes(activetab);
                    }

                }
            }
        }
    });

    function loadMorePhotos(activeTab) {
        var last_id = $('#photoId').val();
        //var photo_id = $('#photo_id').val();
        var photo_id = $('#currentImgId').val();
        
        var base_url = $('#base_url').val();
        var photo_url = $('#photo_path').val();
        var url = base_url + "/photos_reference";
        var bindData = '';
        if (last_id > 0) {
            $.ajax({
                type: "POST",
                url: url,
                dataType: 'json',
                data: {
                    last_id: last_id,
                    photo_id: photo_id,
                    activeTab: activeTab
                },
                beforeSend: function() {
                    ajaxFlag = true;
                    $('.facebook_style').show();
                },
                success: function(data) {

                    if (data['totalResultCount'] > 0) {

                        //var addCounter = parseInt($('#currentcount').html()) + parseInt(data['totalResultCount']);
                        //$('#currentcount').html(addCounter);
                        for (var i = 0; i < data['totalResultCount']; i++) {

                            lastphotoid = data['result_display_data'][i].photo_id;
                            var ImageUrl = photo_url + data['result_display_data'][i].photo_filename;
                            var title = htmlentities($.fn.stripslashes(data['result_display_data'][i].photo_title, "ENT_QUOTES"));
                            var description = htmlentities($.fn.stripslashes(data['result_display_data'][i].photo_description, "ENT_QUOTES"));

                            bindData += '<li>';
                            bindData += '<div class="referenceImg"><a rel="example_group" href="' + ImageUrl + '" class="productImage pop" title="' + title + '"> <img src="' + ImageUrl + '" width="233" height="173" alt="' + title + '" /></a></div> ';
                            bindData += '<div class="referenceContent">'
                            bindData += '<h3>' + title + '</h3>'
                            bindData += '<p>' + description + '</p>';
                            bindData += '<div class="refViewmore"><a href="' + base_url + '/photosdetail/' + b64.encode(lastphotoid) + '">View More</a></div>';
                            bindData += '</div></li>';
                        }
                        $('#photoId').val(lastphotoid);
                        var displayCount = $('#displayCount').val();
                        displayCount = parseInt(displayCount) + parseInt(data['totalResultCount']);
                        $('#displayCount').val(displayCount);

                    } else {
                        $('#photoId').val('0');
                    }

                    $(".referenceList").append(bindData);
                    $(".facebook_style").hide();
                    ajaxFlag = false;
                    //}
                }
            }).done(function() {
                // START CALL FANCYBOX
                $("a[rel=example_group]").fancybox({
                    'overlayShow': 'false',
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'titlePosition': 'inside',
                    'titleFormat': formatTitle
                });
                // STOP CALL FANCYBOX 
            });
        }
    }



    function loadMoreVideos(activeTab) {
        var last_id = $('#videoId').val();
        var photo_id =  $('#currentImgId').val();
        var base_url = $('#base_url').val();
        var video_url = $('#video_url').val();
        var url = base_url + "/photos_reference";
				var bindData = '';
        if (last_id > 0) {
            $.ajax({
                type: "POST",
                url: url,
                dataType: 'json',
                data: {
                    last_id: last_id,
                    photo_id: photo_id,
                    activeTab: activeTab
                },
                beforeSend: function() {
                    ajaxFlag = true;
                    $('.facebook_style').show();
                },
                success: function(data) {
									//alert(data['totalResultCount']); return false;
                    if (data['totalResultCount'] > 0) {
                        var displayCount = $('#displayCount').val();
                        var keyCount = 0;
                        for (var i = 0; i < data['totalResultCount']; i++) {

                            lastphotoid = data['result_display_data'][i].video_id;
                            var ImageUrl = video_url + '/images/medium/' + data['result_display_data'][i].video_image;
                            var title = htmlentities($.fn.stripslashes(data['result_display_data'][i].video_title, "ENT_QUOTES"));
                            var description = htmlentities($.fn.stripslashes(data['result_display_data'][i].video_description, "ENT_QUOTES"));
                            var duration = htmlentities($.fn.stripslashes(data['result_display_data'][i].video_duration, "ENT_QUOTES"));
                            var videographer_name = htmlentities($.fn.stripslashes(data['result_display_data'][i].videographer_name, "ENT_QUOTES"));
                            var video_filename = htmlentities($.fn.stripslashes(data['result_display_data'][i].video_filename, "ENT_QUOTES"));
                            keyCount = parseInt(displayCount) + parseInt(i);
                            bindData += '<li>';
                            bindData += '<div class="referenceImg">';
                            bindData += '<a rel="gallery_video_group" id="showVideos_' + keyCount + '" href="#showVideosId" class="productImage pop" title="' + title + '">';
                            bindData += '<img src="' + ImageUrl + '" width="233" height="173" alt="' + title + '" /></a></div> ';
                            bindData += '<div class="referenceContent">'
                            bindData += '<h3>' + title + '</h3>'
                            bindData += '<h4>' + duration + '</h4>';
                            bindData += '<p>' + description + '</p>';
                            bindData += '</div></li>';

                            bindData += '<input type="hidden" name="videoTitle' + keyCount + '" id="videoTitle' + keyCount + '" value="' + title + '" readonly="readonly" />';
                            bindData += '<input type="hidden" name="videoDesc' + keyCount + '" id="videoDesc' + keyCount + '" value="' + description + '" readonly="readonly" />';
                            bindData += '<input type="hidden" name="videographerName' + keyCount + '" id="videographerName' + keyCount + '" value="' + videographer_name + '" readonly="readonly" />';
                            bindData += '<input type="hidden" name="videoFilename' + keyCount + '" id="videoFilename' + keyCount + '" value="' + video_filename + '" readonly="readonly" />';
                            bindData += '<input type="hidden" name="videoImage' + keyCount + '" id="videoImage' + keyCount + '" value="' + data['result_display_data'][i].video_image + '" readonly="readonly" />';
                            bindData += '<input type="hidden" name="videoImage_' + keyCount + '" id="videoImage_' + keyCount + '" value="' + data['result_display_data'][i].video_image + '" />';
                        }
                        $('#videoId').val(lastphotoid);
                        displayCount = parseInt(displayCount) + parseInt(data['totalResultCount']);
                        $('#displayCount').val(displayCount);

                    } else {
                        $('#videoId').val('0');
                    }
                    $(".referenceList").append(bindData);
                    $(".facebook_style").hide();
                    ajaxFlag = false;
                    //}
                }
            }).done(function() {
                $("a[rel=gallery_video_group]").fancybox({
                    'transitionIn': 'elastic',
                    'transitionOut': 'fade',
                    'titlePosition': 'inside',
                    'showNavArrows': false,
                    'scrolling': 'no',
                    'titleShow': false,
                    onStart: function() {
                        initPlayers();
                    }
                });
            });
        }
    }

    function loadMoreAudios(activeTab) {
        var last_id = $('#audioId').val();
        var photo_id = $('#photo_id').val();
        var base_url = $('#base_url').val();
        var video_url = $('#audio_url').val();
        var url = base_url + "/photos_reference";
        var dateTitle = $('#dateTitle').val();
        var bindData = '';
        if (last_id > 0) {
            $.ajax({
                type: "POST",
                url: url,
                dataType: 'json',
                data: {
                    last_id: last_id,
                    photo_id: photo_id,
                    activeTab: activeTab
                },
                beforeSend: function() {
                    ajaxFlag = true;
                    $('.facebook_style').show();
                },
                success: function(data) {

                    if (data['totalResultCount'] > 0) {
                        var displayCount = $('#displayCount').val();
                        var keyCount = 0;
                        for (var i = 0; i < data['totalResultCount']; i++) {

                            lastaudioid = data['result_display_data'][i].audio_id;
                            var title = htmlentities($.fn.stripslashes(data['result_display_data'][i].audio_title, "ENT_QUOTES"));
                            var date = htmlentities($.fn.stripslashes(data['result_display_data'][i].audio_date, "ENT_QUOTES"));
                            var audio_filename = htmlentities($.fn.stripslashes(data['result_display_data'][i].audio_filename, "ENT_QUOTES"));
                            keyCount = parseInt(displayCount) + parseInt(i);
                            bindData += '<li>';
                            bindData += '<h3><a rel="gallery_audio_group" id="showAudios_' + keyCount + '" href="#showAudioId" class="productImage pop" title="' + title + '"> ' + title + '</a>\n\
                            <input type="hidden" name="audioFile_' + keyCount + '" id="audioFile_' + keyCount + '" value="' + audio_filename + '" /></h3>'
                            bindData += '<p>' + dateTitle + ': ' + date + '</p>';
                            bindData += '</li>';
                        }
                        $('#audioId').val(lastaudioid);
                        displayCount = parseInt(displayCount) + parseInt(data['totalResultCount']);
                        $('#displayCount').val(displayCount);

                    } else {
                        $('#audioId').val('0');
                    }
                    $(".referenceList").append(bindData);
                    $(".facebook_style").hide();
                    ajaxFlag = false;
                    //}
                }
            }).done(function() {
                $("a[rel=gallery_audio_group]").fancybox({
                    'transitionIn': 'elastic',
                    'transitionOut': 'fade',
                    'titlePosition': 'inside',
                    'showNavArrows': false,
                    'scrolling': 'no',
                    onStart: function() {
                        initAudioPlayers();
                    }
                });
            });
        }
    }

    function loadMoreCartoons(activeTab) {
        var last_id = $('#cartoonId').val();
        var photo_id = $('#photo_id').val();
        var base_url = $('#base_url').val();
        var cartoon_url = $('#cartoon_path').val();
        var url = base_url + "/photos_reference";
        var bindData = '';
        if (last_id > 0) {
            $.ajax({
                type: "POST",
                url: url,
                dataType: 'json',
                data: {
                    last_id: last_id,
                    photo_id: photo_id,
                    activeTab: activeTab
                },
                beforeSend: function() {
                    ajaxFlag = true;
                    $('.facebook_style').show();
                },
                success: function(data) {

                    if (data['totalResultCount'] > 0) {

                        for (var i = 0; i < data['totalResultCount']; i++) {

                            lastphotoid = data['result_display_data'][i].cartoon_id;
                            var ImageUrl = cartoon_url + data['result_display_data'][i].cartoon_filename;
                            var title = htmlentities($.fn.stripslashes(data['result_display_data'][i].cartoon_title, "ENT_QUOTES"));
                            var description = htmlentities($.fn.stripslashes(data['result_display_data'][i].cartoon_description, "ENT_QUOTES"));

                            bindData += '<li>';
                            bindData += '<div class="referenceImg"><a rel="gallery_cartoon_group" href="' + ImageUrl + '" class="productImage pop" title="' + title + '"> <img src="' + ImageUrl + '" width="233" height="173" alt="' + title + '" /></a></div> ';
                            bindData += '<div class="referenceContent">'
                            bindData += '<h3>' + title + '</h3>'
                            bindData += '<p>' + description + '</p>';
                            bindData += '<div class="refViewmore"><a href="' + base_url + '/cartoondetail/' + b64.encode(lastphotoid) + '">View More</a></div>';
                            bindData += '</div></li>';
                        }
                        $('#cartoonId').val(lastphotoid);
                        var displayCount = $('#displayCount').val();
                        displayCount = parseInt(displayCount) + parseInt(data['totalResultCount']);
                        $('#displayCount').val(displayCount);

                    } else {
                        $('#cartoonId').val('0');
                    }

                    $(".referenceList").append(bindData);
                    $(".facebook_style").hide();
                    ajaxFlag = false;
                    //}
                }
            }).done(function() {
                // START CALL FANCYBOX
                $("a[rel=gallery_cartoon_group]").fancybox({
                    'overlayShow': 'false',
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'titlePosition': 'inside',
                    'titleFormat': formatCartoonTitle
                });
                // STOP CALL FANCYBOX 
            });
        }
    }

    function loadMorePosters(activeTab) {
        var last_id = $('#posterId').val();
        var photo_id = $('#photo_id').val();
        var base_url = $('#base_url').val();
        var poster_path = $('#poster_path').val();
        var poster_path_main = $('#poster_path_main').val();
        var url = base_url + "/photos_reference";
        var bindData = '';
        if (last_id > 0) {
            $.ajax({
                type: "POST",
                url: url,
                dataType: 'json',
                data: {
                    last_id: last_id,
                    photo_id: photo_id,
                    activeTab: activeTab
                },
                beforeSend: function() {
                    ajaxFlag = true;
                    $('.facebook_style').show();
                },
                success: function(data) {
                    if (data['totalResultCount'] > 0) {
                        for (var i = 0; i < data['totalResultCount']; i++) {
                            lastposterid = data['result_display_data'][i].poster_id;
                            var ImageUrl_Main = poster_path_main + data['result_display_data'][i].poster_filename;
                            var ImageUrl = poster_path + data['result_display_data'][i].poster_filename;
                            var title = htmlentities($.fn.stripslashes(data['result_display_data'][i].poster_title, "ENT_QUOTES"));
                            var description = htmlentities($.fn.stripslashes(data['result_display_data'][i].poster_description, "ENT_QUOTES"));

                            bindData += '<li>';
                            bindData += '<div class="referenceImg"><a rel="example_group" href="' + ImageUrl_Main + '" class="productImage pop" title="' + title + '"> <img src="' + ImageUrl + '" width="233" height="173" alt="' + title + '" /></a></div> ';
                            bindData += '<div class="referenceContent">';
                            bindData += '<h3>' + title + '</h3>';
                            bindData += '<p>' + description + '</p>';
                            bindData += '<div class="refViewmore"><a href="' + base_url + '/postersdetail/' + b64.encode(lastposterid) + '">View More</a></div>';
                            bindData += '</div></li>';
                        }
                        $('#posterId').val(lastposterid);
                        var displayCount = $('#displayCount').val();
                        displayCount = parseInt(displayCount) + parseInt(data['totalResultCount']);
                        $('#displayCount').val(displayCount);

                    } else {
                        $('#posterId').val('0');
                    }

                    $(".referenceList").append(bindData);
                    $(".facebook_style").hide();
                    ajaxFlag = false;
                    //}
                }
            }).done(function() {
                // START CALL FANCYBOX
                $("a[rel=example_group]").fancybox({
                    'overlayShow': 'false',
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'titlePosition': 'inside',
                    'titleFormat': formatTitle
                });
                // STOP CALL FANCYBOX 
            });
        }
    }

    function loadMoreStamps(activeTab) {
        var last_id = $('#stampId').val();
        var photo_id = $('#photo_id').val();
        var base_url = $('#base_url').val();
        var stamp_path = $('#stamp_path').val();
        var url = base_url + "/photos_reference";
        var bindData = '';
        if (last_id > 0) {
            $.ajax({
                type: "POST",
                url: url,
                dataType: 'json',
                data: {
                    last_id: last_id,
                    photo_id: photo_id,
                    activeTab: activeTab
                },
                beforeSend: function() {
                    ajaxFlag = true;
                    $('.facebook_style').show();
                },
                success: function(data) {
                    if (data['totalResultCount'] > 0) {
                        for (var i = 0; i < data['totalResultCount']; i++) {

                            laststampid = data['result_display_data'][i].stamp_id;
                            var ImageUrl = stamp_path + data['result_display_data'][i].stamp_filename;
                            var title = htmlentities($.fn.stripslashes(data['result_display_data'][i].stamp_title, "ENT_QUOTES"));
                            var description = htmlentities($.fn.stripslashes(data['result_display_data'][i].slug, "ENT_QUOTES"));
                            //alert(title+'-'+ImageUrl+'-'+title+'-'+description);
                            bindData += '<li>';
                            bindData += '<div class="referenceImg"><a rel="example_group" href="' + ImageUrl + '" class="productImage pop" title="' + title + '"> <img src="' + ImageUrl + '" width="233" height="173" alt="' + title + '" /></a></div> ';
                            bindData += '<div class="referenceContent">';
                            bindData += '<h3>' + title + '</h3>';
                            bindData += '<p>' + description + '</p>';
							bindData += '<div class="refViewmore"><a href="' + base_url + '/stampsdetail/' + b64.encode(laststampid) + '">View More</a></div>';
                            bindData += '</div></li>';
                        }
                        $('#stampId').val(laststampid);
                        var displayCount = $('#displayCount').val();
                        displayCount = parseInt(displayCount) + parseInt(data['totalResultCount']);
                        $('#displayCount').val(displayCount);

                    } else {
                        $('#stampId').val('0');
                    }

                    $(".referenceList").append(bindData);
                    $(".facebook_style").hide();
                    ajaxFlag = false;
                    //}
                }
            }).done(function() {
                // START CALL FANCYBOX
                $("a[rel=example_group]").fancybox({
                    'overlayShow': 'false',
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'titlePosition': 'inside',
                    'titleFormat': formatTitle
                });
                // STOP CALL FANCYBOX 
            });
        }
    }
	
	 function loadMoreTributes(activeTab) {
        var last_id = $('#tributeId').val();
        var photo_id = $('#photo_id').val();
        var base_url = $('#base_url').val();
		var tribute_path = $('#tribute_path').val();
        //var tribute_url = $('#tribute_url').val();
        var url = base_url + "/photos_reference";
        var bindData = '';
        if (last_id > 0) {
            $.ajax({
                type: "POST",
                url: url,
                dataType: 'json',
                data: {
                    last_id: last_id,
                    photo_id: photo_id,
                    activeTab: activeTab
                },
                beforeSend: function() {
                    ajaxFlag = true;
                    $('.facebook_style').show();
                },
                success: function(data) {

                    if (data['totalResultCount'] > 0) {

                        for (var i = 0; i < data['totalResultCount']; i++) {

                            lastphotoid = data['result_display_data'][i].personid;
							tributeid = data['result_display_data'][i].tributeid;
							var ImageUrl = tribute_path + data['result_display_data'][i].personphoto;
                            var firstname = htmlentities($.fn.stripslashes(data['result_display_data'][i].firstname, "ENT_QUOTES"));
							var lastname = htmlentities($.fn.stripslashes(data['result_display_data'][i].lastname, "ENT_QUOTES"));
							var personprofile = htmlentities($.fn.stripslashes(data['result_display_data'][i].personprofile, "ENT_QUOTES"));
                            var tributetext = $.trim($.fn.stripslashes(data['result_display_data'][i].tributetext, "ENT_QUOTES"));
							
                            
							
							bindData +='<li><div class="tributesGalleryBoxRef">';
							bindData +='<div class="thumbImg">';
							bindData += '<a  href="'+base_url+'/tribute-detail/'+b64.encode(data['result_display_data'][i].tributeid)+'/'+b64.encode(data['result_display_data'][i].personid)+'"  title="'+data['result_display_data'][i].firstname+' '+data['result_display_data'][i].lastname+'">';
                            
                            if(data['result_display_data'][i].personphoto != '')
                            {    
                                var person_filename = data['result_display_data'][i].personphoto;
                            }
                            else
                            {    
                                var person_filename = "person_nophoto.png";
                            }
                            bindData += '<img src="'+ImageUrl+'" width="141" height="156" alt="'+data['result_display_data'][i].firstname+' '+data['result_display_data'][i].lastname+'" title="'+data['result_display_data'][i].firstname+' '+data['result_display_data'][i].lastname+'" />';
                            
                            bindData += '</a>';
							bindData +='</div><div class="content">';
                            var tributername = data['result_display_data'][i].firstname;
                            var display_tributer_name = '';
                            display_tributer_name = tributername;
							bindData +='<h2>'+display_tributer_name+'</h2>';
							
							var tributerprofile = data['result_display_data'][i].personprofile;
                            var display_tributer_profile = '';
                            display_tributer_profile = tributerprofile;
							bindData +='<h3>'+display_tributer_profile+'</h3>';
                             
                            
							var tributetext = strip_tags(data['result_display_data'][i].tributetext);
                            var display_tribute_text = '';
							if(tributetext.length > 170)
                            {
                                display_tribute_text = tributetext.substr(0,170)+'...';
                            }
                            else
                            {    
                                display_tribute_text = tributetext;
                            }
                            
							bindData +='<p>'+display_tribute_text+'</p>';
                            
							bindData +='<span class="paddNone"><a href="'+base_url+'/tribute-detail/'+b64.encode(data['result_display_data'][i].tributeid)+'/'+b64.encode(data['result_display_data'][i].personid)+'" title="'+data['result_display_data'][i].firstname+' '+data['result_display_data'][i].lastname+' '+data['result_display_data'][i].personprofile+'" </a></span>';
							bindData += '<div class="refViewmore"><a href="' + base_url + '/tribute-detail/' + b64.encode(data['result_display_data'][i].tributeid)+'/'+b64.encode(data['result_display_data'][i].personid) + '">View More</a></div>';
							bindData +='</div></div>';
							bindData +='</li>';   
                        }
                        $('#tributeId').val(lastphotoid);
                        var displayCount = $('#displayCount').val();
                        displayCount = parseInt(displayCount) + parseInt(data['totalResultCount']);
                        $('#displayCount').val(displayCount);

                    } else {
                        $('#tributeId').val('0');
                    }

                    $(".referenceList").append(bindData);
                    $(".facebook_style").hide();
                    ajaxFlag = false;
                    //}
                }
            }).done(function() {
                // START CALL FANCYBOX
                $("a[rel=gallery_cartoon_group]").fancybox({
                    'overlayShow': 'false',
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'titlePosition': 'inside',
                    'titleFormat': formatCartoonTitle
                });
                // STOP CALL FANCYBOX 
            });
        }
    }
    
    */

    $.fn.stripslashes = function(str) {
        str = str.replace(/\\'/g, '\'');
        str = str.replace(/\\"/g, '"');
        str = str.replace(/\\\\/g, '\\');
        str = str.replace(/\\0/g, '\0');
        return str;
    };

    // START FOR VIDEOS
    $("a[rel=gallery_video_group]").fancybox({
        'transitionIn': 'elastic',
        'transitionOut': 'fade',
        'titlePosition': 'inside',
        'showNavArrows': false,
        'scrolling': 'no',
        'titleShow': false,
        onStart: function() {
            initPlayers();
        }
    });

    // START FOR AUDIOS
    $("a[rel=gallery_audio_group]").fancybox({
        'transitionIn': 'elastic',
        'transitionOut': 'fade',
        'titlePosition': 'inside',
        'showNavArrows': false,
        'scrolling': 'no',
        onStart: function() {
            initAudioPlayers();
        }
    });


    // STOP FOR AUDIOS

    $("#myTable").tablesorter({
        sortList: [[0, 0]],
        scrollHeight: 100,
        widgets: ['scroller']
    });
});



// START FOR VIDEO

var video_url = $('#video_url').val();
var video_image_url = $('#video_image_url').val();

function initPlayers() {

    var video_url = $('#video_url').val();
    var video_image_url = $('#video_image_url').val();

    var quality = $('#quality').val();
    var video_file_url = video_url + quality + "/";

    var videoDisplay = '';

    videoDisplay += '[';
    for (i = 0; i < $(".referenceList li").length; i++) {

        var videoFileName = $('#videoFilename' + i).val();
        //alert(videoFileName);
        if (videoFileName != undefined) {
            var vFileName = videoFileName.slice(0, videoFileName.lastIndexOf("."));
            //videoDisplay +=  '{ title: "'+$('#videoTitle'+i).val()+'", artist: "'+$('#videographerName'+i).val()+'", webmv: "'+video_file_url+vFileName+'.webm", m4v: "'+video_file_url+vFileName+'.mp4", poster: "'+video_image_url+"medium/"+$('#videoImage'+i).val()+'"}';

            videoDisplay += '{ webmv: "' + video_file_url + vFileName + '.webm", m4v:"' + video_file_url + vFileName + '.mp4", poster: "' + video_image_url + 'medium/' + $('#videoImage_' + i).val() + '"}';

            if (i != ($(".referenceList li").length - 1)) {
                videoDisplay += ',';
            }
        }
    }
    videoDisplay += ']';
    //alert(videoDisplay);
    videoPlaylist = new jPlayerPlaylist({
        jPlayer: "#jquery_jplayer_1",
        cssSelectorAncestor: "#jp_container_1"
    }, eval(videoDisplay), {
        swfPath: $("#videoModuleUrl").val() + "jplayer/js",
        solution: 'html, flash',
        autoPlay: false,
        supplied: "webmv, mp4, m4v",
        wmode: "window",
        size: {
            width: "440px",
            height: "270px",
            cssClass: "jp-video-270p"
        }
    });
}

$("#videoGallery li").livequery('click', function(e) {
    var vtitle = $("#vtitle").val();
    var vdesc = $("#vdesc").val();
    var vvideographer = $("#vvideographer").val();
    var videoArray = $(this).find("a").attr('id').split('_');
    //$('#videoCounter').val(videoArray[1]);
    videoPlaylist.select(videoArray[1]);
    videoPlaylist.pause(videoArray[1]);
    if ($('#videoTitle' + videoArray[1]).val() != '') {
        $("#playVideoTitle").html("<span class='vtitle'>" + vtitle + ": </span><span class='vvalue'>" + $('#videoTitle' + videoArray[1]).val() + "</span>");
    }
    if ($('#videoDesc' + videoArray[1]).val() != '') {
        $("#playVideoDesc").html("<span class='vtitle'>" + vdesc + ": </span><span class='vvalue'>" + $('#videoDesc' + videoArray[1]).val() + "</span>");
    }
    if ($('#videographerName' + videoArray[1]).val() != '') {
        $("#playVideographer").html("<span class='vtitle'>" + vvideographer + ": </span><span class='vvalue'>" + $('#videographerName' + videoArray[1]).val() + "</span>");
    }
    //initPlayers();  
    //$("#playVideoTitle").html($('#videoTitle'+videoArray[1]).val());
    //$("#playVideoDesc").html($('#videoDesc'+videoArray[1]).val()); 
    //$("#playVideographer").html($('#videographerName'+videoArray[1]).val());         

});
//
//// START FOR ON CLICK PLAYER PREVIOUS
//$("#thumbPrev").livequery('click', function(e) {
//    if ($('#videoCounter').val() <= 0) {
//        $('#videoCounter').val(0);
//    } else {
//        $('#videoCounter').val(parseInt($('#videoCounter').val()) - 1);
//    }
//    for (videoCnt = 0; videoCnt < $("#videoGallery li").length; videoCnt++) {
//        if (videoCnt == $('#videoCounter').val()) {
//            videoPlaylist.select($('#videoCounter').val());
//            videoPlaylist.pause($('#videoCounter').val());
//            $("#playVideoTitle").html($('#videoTitle' + $('#videoCounter').val()).val());
//            $("#playVideoDesc").html($('#videoDesc' + $('#videoCounter').val()).val());
//            $("#playVideographer").html($('#videographerName' + $('#videoCounter').val()).val());
//        }
//    }
//});
//// END FOR ON CLICK PLAYER PREVIOUS   
//
// START CODE FOR QUALITY
$("#quality_720").livequery('click', function(e) {
    var qualityArray = $(this).attr('id').split("_");
    $("#quality").val(qualityArray[1]);
    $("#quality_720").addClass("active");
    $("#quality_360").removeClass("active");
    $("#quality_240").removeClass("active");
    initPlayers();
    videoPlaylist.select(videoPlaylist.current);
    videoPlaylist.pause(videoPlaylist.current);
});

$("#quality_360").livequery('click', function(e) {
    var qualityArray = $(this).attr('id').split("_");
    $("#quality").val(qualityArray[1]);
    $("#quality_360").addClass("active");
    $("#quality_240").removeClass("active");
    $("#quality_720").removeClass("active");
    initPlayers();
    videoPlaylist.select(videoPlaylist.current);
    videoPlaylist.pause(videoPlaylist.current);
});

$("#quality_240").livequery('click', function(e) {
    var qualityArray = $(this).attr('id').split("_");
    $("#quality").val(qualityArray[1]);
    $("#quality_240").addClass("active");
    $("#quality_360").removeClass("active");
    $("#quality_720").removeClass("active");
    initPlayers();
    videoPlaylist.select(videoPlaylist.current);
    videoPlaylist.pause(videoPlaylist.current);
});
// END CODE FOR QUALITY
//
//// START TO STOP CLICK SHOW IMAGE
//$(".jp-stop").livequery('click', function(e) {
//    videoPlaylist.select(videoPlaylist.current);
//    videoPlaylist.pause(videoPlaylist.current);
//});
//// STOP TO STOP CLICK SHOW IMAGE   
//
//// END FOR VIDEO

//var audio_url = $('#audio_url').val();
function initAudioPlayers() {
    var audio_url = $('#audio_url').val();
    var audio_file_url = audio_url;

    var total_audio = parseInt($("#displayCount").val());
    //alert(total_audio);
    var audioDisplay = '';
    audioDisplay += '[';
    for (a = 0; a < total_audio; a++) {

        audioDisplay += '{ oga: "' + audio_file_url + $('#audioFile_' + a).val() + '.ogg", mp3:"' + audio_file_url + $('#audioFile_' + a).val() + '.mp3"}';
        if (a != ((total_audio) - 1)) {
            audioDisplay += ',';
        }
    }
    audioDisplay += ']';
    //alert(audioDisplay);
    audioPlaylist = new jPlayerPlaylist({
        jPlayer: "#jquery_jplayer_2",
        cssSelectorAncestor: "#jp_container_2"
    }, eval(audioDisplay), {
        swfPath: "js",
        supplied: "oga, mp3",
        wmode: "window"
    });
}

$("#audioPrev").livequery('click', function(e) {
    var total_audio = parseInt($("#displayCount").val());

    for (var k = 0; k < total_audio; k++) {
        if (k == audioPlaylist.current) {
            audioPlaylist.select(audioPlaylist.current);
            audioPlaylist.pause(audioPlaylist.current);
        }
    }
    showAudioDetail(audioPlaylist.current);
    $.fn.carouselresize(audioPlaylist.current);
});

$("#audioNext").livequery('click', function(e) {
    var total_audio = parseInt($("#displayCount").val());

    for (var m = 0; m < total_audio; m++) {
        if (m == audioPlaylist.current) {
            audioPlaylist.select(audioPlaylist.current);
            audioPlaylist.pause(audioPlaylist.current);
        }
    }
    showAudioDetail(audioPlaylist.current);
    $.fn.carouselresize(audioPlaylist.current);
});

$("#referenceList li").livequery('click', function(e) {

    var selected_id = $(this).find("a").attr('id').split('_');
    var id = selected_id[1];

    var total_audio = parseInt($("#displayCount").val());
    for (var m = 0; m < total_audio; m++) {
        if (m == id) {
            audioPlaylist.select(id);
            audioPlaylist.pause(id);
            audioPlaylist.current = parseInt(id);
        }
    }
    showAudioDetail(id);
    $.fn.carouselresize(id);
});

function showAudioDetail(id){
    
    $('div[class^="audio_detail_"]').each(function() {
        var selected_id = ($(this).attr('class')).split('_');
        var show_id = selected_id[2];


        if (id == show_id)
        {
            $(this).show();
        }
        else
        {
            $(this).hide();
        }
    });
}

$.fn.carouselresize = function(id) {

    $("#mycarousel_" + id + " img").each(function() {

        // $(this).load(function(){

        var containerWidth, containerHeight, containerRatio;
        var imageWidth, imageHeight, imageRatio;

        var $gaBG = $(this);
        // containerWidth = $(this).parent().parent().width();
        // containerHeight = $(this).parent().parent().height();  

        containerWidth = 550;
        containerHeight = 525;

        containerRatio = containerWidth / containerHeight;

        imageWidth = this.width;
        imageHeight = this.height;
        imageRatio = imageWidth / imageHeight;

        if (imageRatio > containerRatio) {
            $gaBG.width(containerWidth);
            $gaBG.height(containerWidth * (1 / imageRatio));
        }
        else if (imageRatio < containerRatio) {
            $gaBG.width(containerHeight * imageRatio);
            $gaBG.height(containerHeight);
        }
        else if (imageRatio == containerRatio) {
            if (imageWidth <= imageHeight) {
                $gaBG.width(containerWidth);
                $gaBG.height(containerWidth * (1 / imageRatio));
            }
            else {
                $gaBG.width(containerHeight * imageRatio);
                $gaBG.height(containerHeight);
            }
        }

        // })
    });

    $("#mycarousel_" + id).jcarousel({scroll: 1});

}


function file_exists(url) {

    var req = this.window.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : new XMLHttpRequest();
    if (!req) {
        throw new Error('XMLHttpRequest not supported');
    }

    // HEAD Results are usually shorter (faster) than GET
    req.open('HEAD', url, false);
    req.send(null);
    if (req.status == 200) {
        return true;
    }

    return false;
}

(function($) {
        $(window).load(function() {
            //$(".scrollGrid").mCustomScrollbar({
            //  theme: "dark-thick"
            //});
            $(".scroller_tbl").mCustomScrollbar({
                theme: "dark-thick"
            });
        });
    })(jQuery);
	
function strip_tags (input, allowed) {
  
  allowed = (((allowed || "") + "").toLowerCase().match(/<[a-z][a-z0-9]*>/g) || []).join(''); 
  var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,
    commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;
  return input.replace(commentsAndPhpTags, '').replace(tags, function ($0, $1) {
    return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';
  });
}