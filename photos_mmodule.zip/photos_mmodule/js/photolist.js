jQuery(function ($) {

    var ajaxFlag = false;
    var phototitle = $('#phototitle').val();
    var photodesc = $('#photodesc').val();
    var photoplace = $('#photoplace').val();
    var photopeople = $('#photopeople').val();
    var photosource = $('#photosource').val();
    var norecord = $('#norecord').val();
    $(".volumelistcls").uniform();

    // START LEFT COLUMN WCAG
    $("#leftPanelCheckboxListing").show();
    $("#jsdisablecheckboxlisting").hide();
    // END LEFT COLUMN WCAG

    $("#updates").show();
    $("#updates1").hide();

    // START GALLERY WCAG
    $("#booksAllDiv").show();
    $("#booksAllDivPhp").hide();
    // STOP GALLERY WCAG

    // START PRINT BUTTON WCAG
    $("#printButton").show();
    // START PRINT BUTTON WCAG   

    // START SEARCH WCAG
    $("#photoSearchBlock").show();
    $("#photoSearchBlockPhp").hide();
    // STOP SEARCH WCAG

    // GET GLOBAL SEARCH KEYWORD FOR AJAX RESULT
    var global_search_keyword = $("#global_search_keyword").val();
    var photo_search_keyword = $("#photoKeyword1").val();
    var photo_category = $("#photo_category").val();

    // RESET COOKIE
    var a, b, c, d;
    if (jQuery.cookie("photo_startyear") != null) {
        a = jQuery.cookie("photo_startyear", null);
    } else {
        a = jQuery.cookie("photo_startyear");
    }
    if (jQuery.cookie("photo_endyear") != null) {
        b = jQuery.cookie("photo_endyear", null);
    } else {
        b = jQuery.cookie("photo_endyear");
    }
    if (jQuery.cookie("photo_filteryear") != null) {
        c = jQuery.cookie("photo_filteryear", null);
    } else {
        c = jQuery.cookie("photo_filteryear");
    }
    if (jQuery.cookie("photo_filteryearcheckbox") != null) {
        d = jQuery.cookie("photo_filteryearcheckbox", null);
    } else {
        d = jQuery.cookie("photo_filteryearcheckbox");
    }
    // RESET COOKIE    


    var baseURL = $('#baseUrl').val();
    var photo_download_path = $('#photo_download_path').val();
    var lang = $('#language').val();
    var photo_url = $('#photo_url').val();
    var photo_small_url = $('#photo_small_url').val();
    var photo_medium_url = $('#photo_medium_url').val();
    var smallImage = '';
    var mediumImage = '';
    var orgImage = '';
    var photoClass = '';
    var checkbox_flag = false;
    var slider_flag = false;
    var from_year = '';
    var to_year = '';

    var galleries = $('.ad-gallery').adGallery();

    $('.ad-image a img').livequery('click', function (e) {
        var currentActiveImgId = $(this).attr("id");
        $('.ad-image a').fancybox({
            'transitionIn': 'elastic',
            'transitionOut': 'fade',
            'titleShow': false,
            'imgid': currentActiveImgId,
        });

        viewtag(currentActiveImgId);
        function viewtag(pic_id)
        {
            $('.ad-loader').show();
            $path = baseURL + '/taglist';
            $.post($path, "pic_id=" + pic_id + "&imgtype=large", function (datalarge) {
                $('.ad-loader').hide();
                //$('#taglist ol').html(datalarge.lists);
                $('#tagbox1').html(datalarge.boxeslarge);
               // $('#copyright_content').html('');
              //  $('#copyright_content').html(data.copyright);
            }, "json");

        }

    });


    // START FOR ON THUMB IMAGE CLICK DISPLAY DESCRIPTION
    $("#photoListUl li a img").livequery('click', function (e) {

        // $('.referenceContent').css('display', 'none');
        // $('.otherRef').css('display', 'block');
        if($('.referenceContent').is(':visible')) {
            $('.otherRef').trigger( "click" );
        }
        $("#currentImgId").val(this.id);

        var currentActiveImgId = $(this).attr("id");
        var photoLIId = $(this).parent().parent().attr('id');
        var currentDisp = photoLIId.match(/[0-9]+/);
        var totalPrev = $("#photoListUl li").length;
        var j = 0;
        for (j = 0; j < totalPrev; j++) {
            if (j == currentDisp) {
                $('#photoDescription' + j).css('display', '');
                //other_ref(currentDisp);		
            } else {
                $('#photoDescription' + j).css('display', 'none');
            }
        }
        // GET THE TAG ID
        viewtag(currentActiveImgId);
        function viewtag(pic_id)
        {
            $('.ad-loader').show();
            $path = baseURL + '/taglist';
            $.post($path, "pic_id=" + pic_id + "&imgtype=normal", function (data) {
                $('.ad-loader').hide();
                $('#taglist ol').html(data.lists);
                $('#tagbox').html(data.boxes);
                $('#copyright_content').html('');
                $('#copyright_content').html(data.copyright);
            }, "json");
        }

    });
    // STOP FOR ON THUMB IMAGE CLICK DISPLAY DESCRIPTION    

    //Get photo id click on main image next button


    $(".ad-next").livequery('click', function (e) {
        var currentDisp = parseInt($("#currentImgIndex").val());
        var totalPrev = $("#photoListUl li").length;
        var currentActiveImgId = '';
        var j = 0;
        for (j = 0; j < totalPrev; j++) {
            if (j == currentDisp) {
                var liId = '#gandhiphoto' + currentDisp + ' a img';
                currentActiveImgId = $(liId).attr('id');
                // $('.referenceContent').css('display', 'none');
                // $('.otherRef').css('display', 'block');
                if($('.referenceContent').is(':visible')) {
                    $('.otherRef').trigger( "click" );
                }
                // alert(currentActiveImgId);

                $("#currentImgId").val(currentActiveImgId);
                break;
            }
        }

        viewtag(currentActiveImgId); // view all tags available on page load
        function viewtag(pic_id)
        {

            // get the tag list with action remove and tag boxes and place it on the image.
            //$.post( "taglist.php" ,  "pic_id=" + pic_id, function( data ) {
            $('.ad-loader').show();
            $path = baseURL + '/taglist';
            //$.post( $("#baseUrlpath").val() + 'taglist' ,  "pic_id=" + pic_id, function( data ) {
            $.post($path, "pic_id=" + pic_id + "&imgtype=normal", function (data) {
                $('.ad-loader').hide();
                $('#taglist ol').html(data.lists);
                $('#tagbox').html(data.boxes);
                $('#copyright_content').html('');
                $('#copyright_content').html(data.copyright);
            }, "json");

        }
        $('#tagbox').on('mouseover', '.tagview', function ( )
        {
            var pos = $(this).position();
            $(this).css({opacity: 1.0}); // div appears when opacity is set to 1.
        }).on('mouseout', '.tagview', function ( ) {
            $(this).css({opacity: 1.0}); // hide the div by setting opacity to 0.
        });

        // other_ref(currentActiveImgId);				   
    });

    //Get photo id click on main image next button
    $(".ad-prev").livequery('click', function (e) {
        var currentDisp = parseInt($("#currentImgIndex").val());
        var totalPrev = $("#photoListUl li").length;
        var currentActiveImgId = '';
        var j = 0;
        for (j = 0; j < totalPrev; j++) {
            if (j == currentDisp) {
                var liId = '#gandhiphoto' + currentDisp + ' a img';
                currentActiveImgId = $(liId).attr('id');
                // $('.referenceContent').css('display', 'none');
                // $('.otherRef').css('display', 'block');
                if($('.referenceContent').is(':visible')) {
                    $('.otherRef').trigger( "click" );
                }
                $("#currentImgId").val(currentActiveImgId);
                break;
            }
        }
        viewtag(currentActiveImgId); // view all tags available on page load

        function viewtag(pic_id)
        {
            // get the tag list with action remove and tag boxes and place it on the image.
            //$path = "http://localhost/ghp-drupal/trunk/backend/taglist";
            $('.ad-loader').show();
            $path = baseURL + '/taglist';
            $.post($path, "pic_id=" + pic_id + "&imgtype=normal", function (data) {
                $('.ad-loader').hide();
                $('#taglist ol').html(data.lists);
                $('#tagbox').html(data.boxes);
                $('#copyright_content').html('');
                $('#copyright_content').html(data.copyright);
            }, "json");

        }
        $('#tagbox').on('mouseover', '.tagview', function ( ) {

            var pos = $(this).position();
            $(this).css({opacity: 1.0}); // div appears when opacity is set to 1.
        }).on('mouseout', '.tagview', function ( ) {
            $(this).css({opacity: 1.0}); // hide the div by setting opacity to 0.
        });

    });

    /*function other_ref(currentActiveImgId) {
     var base_url = $('#base_url').val();
     var url = base_url + "/photos_other_reference/"+currentActiveImgId;
     
     var bindData = '';
     
     $.ajax({
     type: "POST",
     url: url,
     dataType: 'html',
     data: {
     currentImgIndex : currentActiveImgId
     },
     beforeSend: function() {
     ajaxFlag = true;
     },
     success: function(data) {
     
     //alert(data);
     //return false;
     
     ajaxFlag = false;
     }
     });
     }
     
     */
    // START FOR CLICK ON NEXT & SHOW
 $.UrlExists = function(url) {
	var http = new XMLHttpRequest();
    http.open('HEAD', url, false);
    http.send();
    return http.status!=404;
} 

    $("#photoSmallNext").livequery('click', function (e) {

        // IF TOTAL RECORDS LESS THAN
        if (parseInt($('#totalRecords').val()) > parseInt($('#paging').val())) {
            var extra_url = $("#display_photos_url").val();
            if (extra_url == '' || extra_url == undefined)
            {
                var pageurl = baseURL + "/get_ajax_photos_data";
            }
            else
            {
                var pageurl = baseURL + "/get_ajax_photos_data/" + extra_url;
            }

            if (ajaxFlag == false) {
                // START FOR AJAX PHOTO LOAD
                $.ajax({
                    type: "POST",
                    url: pageurl,
                    dataType: 'json',
                    data: {
                        language: lang,
                        page: $('#paging').val(),
                        selected_checkbox: $('#selected_checkbox').val(),
                        global_search_keyword: global_search_keyword,
                        photo_category: photo_category,
                        photo_search_keyword: photo_search_keyword
                    },
                    beforeSend: function () {
                        ajaxFlag = true;
                        $("#ajaxFlagSet").val(1);
                        $("#GalleryLoaderDisplay").show();
                    },
                    success: function (data) {
                        var photoList = '';
                        var photoDesc = '';
                        var photoLink = '';
                        var descCounter = $("#photoListUl li").length;
                        var total_data = data.length;

                        photoList += $("#photoListUl").html();

                        if (data.length > 0) {
                            var totalCount = parseInt($('#totalrecord').html());
                            var dataCount = total_data - 2;
                            var addCounter = parseInt($('#currentcount').html()) + dataCount;
                            if (addCounter <= totalCount) {
                                $('#currentcount').html(addCounter);
                            }
                            else
                            {
                                $('#currentcount').html(totalCount);
                            }
                            for (var i = 0; i < total_data - 2; i++) {

                                smallImage = photo_small_url + data[i].photo_filename;
                                mediumImage = photo_medium_url + data[i].photo_filename;
                                orgImage = photo_url + data[i].photo_filename;
								// var foto = '';
								
								//if($.UrlExists(smallImage)){
								// foto = smallImage;
								// }else{
								// 	foto = photo_medium_url + 'photo-gallery-no-img.jpg';
								// }  

                                var alttext;
                                var titletext;
                                if (data[i].photo_alter_text != '')
                                {
                                    alttext = data[i].photo_alter_text;
                                }
                                else
                                {
                                    alttext = data[i].photo_filename;
                                }

                                if (data[i].photo_title != '')
                                {
                                    titletext = data[i].photo_title;
                                }
                                else
                                {
                                    titletext = data[i].photo_filename;
                                }


                                photoList += '<li id="gandhiphoto' + (parseInt(descCounter) + i) + '"><a href="' + orgImage + '" ><img id="' + data[i].photo_id + '" src="' + smallImage + '" title="' + htmlentities($.fn.stripslashes(titletext)) + '"  width="42" height="42" alt="' + htmlentities($.fn.stripslashes(alttext)) + '"  class="image1" style="vertical-align: middle;" /></a> <input type="hidden" name="year" value="' + data[i].photoyear + '" /></li>';

                                //photoLink += '<div class="download" id="downloadLink">';
                                //photoLink += '<a id="photoDownload" href="" title="Download Current Image">Download Current Image12<img src="'+baseURL+'/sites/all/themes/ghp/images/download-icon.png"></a></div>';

                                photoDesc += '<div class="gallery_inner" id="photoDescription' + (parseInt(descCounter) + i) + '" style="display:none">';

                                if (data[i].photo_title != '')
                                {
                                    photoDesc += '<h3>' + phototitle + ': <span class="phototitle">' + htmlentities($.fn.stripslashes(data[i].photo_title)) + '</span></h3>';
                                }

                                if (data[i].photo_description != '')
                                {
                                    photoDesc += '<h3>' + photodesc + ': <span class="photodesc">' + htmlentities($.fn.stripslashes(data[i].photo_description)) + '</span></h3>';
                                }

                                if (data[i].photo_place != '')
                                {
                                    photoDesc += '<h3>' + photoplace + ': <span class="photodesc">' + $.fn.stripslashes(data[i].photo_place) + '</span></h3>';
                                }

                                if (data[i].photo_people != '')
                                {
                                    photoDesc += '<h3>' + photopeople + ': <span class="photodesc">' + $.fn.stripslashes(data[i].photo_people) + '</span></h3>';
                                }
                                if (data[i].photo_source != '')
                                {
                                    photoDesc += '<h3>' + photosource + ': <span class="photodesc">' + $.fn.stripslashes(data[i].photo_source) + '</span></h3>';
                                }
                                photoDesc += '</div>';
                            }

                            $("#photoListUl").html('');
                            $(".ad-image-wrapper").html('');
                            $("#photoListUl").html(photoList);

                            //$("#photoListUl").append(photoList);
                            $(".gallery").html(photoLink);
                            $("#booksAllDiv").append(photoDesc);
                            // INCREMENT PAGING

                            //var lastPagingValue = parseInt($('#paging').val());
                            var nextValue = parseInt($('#paging').val()) + 18;
                            $('#paging').val(parseInt($('#paging').val()) + 18);
                            // START RELOAD GALLERY
                            $('div #photoSmallNext').remove();
                            $('div #photoSmallPrev').remove();

                            $(".gallery_inner").each(function () {
                                var displayFlag = $(this).css('display');
                                if (displayFlag == 'block')
                                {
                                    var divId = $(this).attr('id');
                                    if (divId != "" && divId != undefined)
                                    {
                                        var ID = parseInt(divId.replace("photoDescription", ''));
                                        $("#lastPagingValue").val(ID);
                                    }
                                }
                            });

                            var galleries = $('.ad-gallery').adGallery({
                                start_at_index: $("#lastPagingValue").val(),
                                callbacks: {
                                    init: function () {
                                        this.preloadAll();
                                    }
                                }
                            });
                            // STOP RELOAD GALLERY
                            $('#totalRecords').val(data[total_data - 1].total_records);
                        }
                        else
                        {
                        }
                        ajaxFlag = false;
                        $("#GalleryLoaderDisplay").hide();
                        $("#ajaxFlagSet").val(0);
                    }
                });
            }
            // STOP FOR AJAX PHOTO LOAD   
        }
    });

    // STOP FOR CLICK ON NEXT & SHOW


    // CHECK FOR LEFT COLUM CHECKBOX CHECKED OR NOT
    /* FILTER CORE SITES BASED ON SELECTED CHECKBOXES VALUE */

    var main_checkbox_obj = $("#leftPanelCheckboxListing > .head");
    var year_checkbox_obj = $("#leftPanelCheckboxListing");

    var total_check_box = (year_checkbox_obj.find("li").length) - 1;

    main_checkbox_obj.find("input:checkbox").change(function () {

        //var main_labelclass = main_checkbox_obj.find(".checked");

        if ($(this).attr('checked') == 'checked')
        {
            year_checkbox_obj.find("li").each(function () {

                var chkobj = $(this).find("input:checkbox");

                if (chkobj.attr('id') != 'CheckBox1')
                {
                    chkobj.attr('checked', 'checked');
                    $(this).find("label").addClass('checked');
                }
            });
        }
        else
        {
            year_checkbox_obj.find("li").each(function () {
                var chkobj = $(this).find("input:checkbox");
                chkobj.removeAttr('checked');
                $(this).find("label").removeClass('checked');
            });
        }
        $(this).getFilterData();
    });

    year_checkbox_obj.find("input:checkbox").change(function () {

        var total_checked = year_checkbox_obj.find("input:checked").length;
        if (main_checkbox_obj.find("input:checkbox").attr('checked') == 'checked')
        {
            total_checked = total_checked - 1;
        }

        if (total_check_box == total_checked)
        {
            main_checkbox_obj.find("input:checkbox").attr('checked', 'checked');
            main_checkbox_obj.find("label").addClass('checked');
        }
        else
        {
            main_checkbox_obj.find("input:checkbox").removeAttr('checked');
            main_checkbox_obj.find("label").removeClass('checked');
        }
        if ($(this).val() != "on")
            $(this).getFilterData();
    });

    $.fn.getFilterData = function ()
    {
        checkbox_flag = true;
        slider_flag = false;

        var extra_url = $("#display_photos_url").val();

        if (extra_url == '' || extra_url == undefined)
        {
            var pageurl = baseURL + "/get_ajax_photos_data";
        }
        else
        {
            var pageurl = baseURL + "/get_ajax_photos_data/" + extra_url;
        }

        var selected_checkbox = '';
        $(".block").find("input:checked").each(function () {
            var chkbox_val = $(this).val();
            if (chkbox_val != "" && chkbox_val != 'on')
            {
                selected_checkbox += chkbox_val + '##';
            }
        });

        $("#selected_checkbox").val(selected_checkbox);

        $.ajax({
            type: "POST",
            url: pageurl,
            dataType: 'json',
            data: {
                language: lang,
                checkbox_filter: 1,
                selected_checkbox: selected_checkbox,
                global_search_keyword: global_search_keyword
            },
            beforeSend: function ( ) {
                // SHOW LOADING
                $("#GalleryLoaderDisplay").show();
            },
            success: function (data) {

                var photoList = '<form name="photoForm" id="photoForm" action="" method="post"><div style="display:inline;"><input type="hidden" name="global_search_keyword" id="global_search_keyword" value="' + global_search_keyword + '" /><input type="hidden" name="baseUrl" id="baseUrl" value="' + $("#baseUrl").val() + '" /><input type="hidden" name="selected_checkbox" id="selected_checkbox" value="' + $("#selected_checkbox").val() + '" /><input type="hidden" name="language" id="language" value="' + $("#language").val() + '" /><input type="hidden" name="photo_url" id="photo_url" value="' + $("#photo_url").val() + '" /><input type="hidden" name="photo_small_url" id="photo_small_url" value="' + $("#photo_small_url").val() + '" /><input type="hidden" name="photo_medium_url" id="photo_medium_url" value="' + $("#photo_medium_url").val() + '" /><input type="hidden" name="paging" id="paging" value="15" /><input type="hidden" name="totalRecords" id="totalRecords" value="' + $("#totalRecords").val() + '" /></div><div class="galleryCon"><div id="gallery" class="ad-gallery"><div class="ad-nav"><div class="ad-thumbs"><ul class="ad-thumb-list" id="photoListUl">';

                var photoDesc = '';
                var displayDesc = '';
                var total_data = data.length;

                if (data.length > 0) {

                    // REMOVE ALL HTML
                    $("#booksAllDiv").html('');

                    if (data[total_data - 1].total_records == 0) {
                        photoList = '<div class="galleryCon" style="min-height: 36px; text-align: center; font-weight: bold;">' + norecord + '</div>';
                        $("#printButton").css('display', 'none');
                    } else {
                        $("#printButton").css('display', '');
                        for (var i = 0; i < total_data - 2; i++) {
                            smallImage = photo_small_url + data[i].photo_filename;
                            mediumImage = photo_medium_url + data[i].photo_filename;
                            orgImage = photo_url + data[i].photo_filename;
                            if (i == 0) {
                                photoClass = 'image0';
                                displayDesc = '';
                            } else {
                                photoClass = 'image1';
                                displayDesc = 'none';
                            }

                            photoList += '<li id="gandhiphoto' + i + '"><a href="' + orgImage + '" title="' + htmlentities($.fn.stripslashes(data[i].photo_title)) + '"><img src="' + smallImage + '"  width="42" height="42" alt="' + htmlentities($.fn.stripslashes(data[i].photo_title)) + '"  class="' + photoClass + '" style="vertical-align: middle;" /></a> <input type="hidden" name="year" value="' + data[i].photoyear + '" /></li>';

                            photoDesc += '<div class="gallery_inner" id="photoDescription' + i + '" style="display:' + displayDesc + '">';

                            if (data[i].photo_title != '')
                            {
                                photoDesc += '<h3>' + phototitle + ': <span class="phototitle">' + htmlentities($.fn.stripslashes(data[i].photo_title)) + '</span></h3>';
                            }

                            if (data[i].photo_description != '')
                            {
                                photoDesc += '<h3>' + photodesc + ': <span class="photodesc">' + htmlentities($.fn.stripslashes(data[i].photo_description)) + '</span></h3>';
                            }

                            if (data[i].photo_place != '')
                            {
                                photoDesc += '<h3>' + photoplace + ': <span class="photodesc">' + $.fn.stripslashes(data[i].photo_place) + '</span></h3>';
                            }

                            if (data[i].photo_people != '')
                            {
                                photoDesc += '<h3>' + photopeople + ': <span class="photodesc">' + $.fn.stripslashes(data[i].photo_people) + '</span></h3>';
                            }
                            if (data[i].photo_source != '')
                            {
                                photoDesc += '<h3>' + photosource + ': <span class="photodesc">' + $.fn.stripslashes(data[i].photo_source) + '</span></h3>';
                            }
                            photoDesc += '</div>';

                        }
                        photoList += '</ul></div></div><div class="ad-image-bg"><div class="ad-image-wrapper"></div></div></div>';
                        if (data[total_data - 2].extra_url_response != '')
                        {
                            photoList += '<input type="hidden" name="display_photos_url" id="display_photos_url" value="' + data[total_data - 1].extra_url_response + '" />';
                        }

                        photoList += '</div><div class="clearfix"></div>';
                    }

                    photoDesc += '</form>';
                    $("#booksAllDiv").html(photoList + photoDesc);

                    // START RELOAD GALLERY
                    $('div #photoSmallNext').remove();
                    $('div #photoSmallPrev').remove();

                    var galleries = $('.ad-gallery').adGallery({
                        current_index: 0,
                        callbacks: {
                            init: function () {
                                this.preloadAll();
                                //            this.slideshow.start();
                                //            this.current_index = 0;
                                //            clearInterval(this.countdown_interval);
                            }
                        }
                    });


                    // STOP RELOAD GALLERY

                    // CHANGE PAGING
                    $('#totalRecords').val(data[total_data - 1].total_records);

                    // HIDE LOADING
                    //$('#photoLoading').hide();                    
                }
                $("#GalleryLoaderDisplay").hide();
            }
        });
    };

    /* END CODE */


    /* SEARCH YEAR SLIDER CODE FOR AJAX CALL TO GET THE RESULT BETWEEN YEARS  */
    $("#mainslider").show();
    $("#mainslider1").hide();
    /*
     $("#Slider4").slider({
     //   orientation: 'horizontal',
     range: true,
     from: 1869, 
     to: 1948,
     scale: [$("#inputslidetest").val()],  
     limits: false,
     step: 1,
     dimension: '',
     skin: "blue",
     callback: function( value ){
     
     // START TO UNCHECK ALL CHECKBOX
     $("#leftPanelCheckboxListing").find("li").each(function () {
     var chkobj = $(this).find("input:checkbox");
     chkobj.removeAttr('checked');
     $(this).find("label").removeClass('checked');
     });
     // END TO UNCHECK ALL CHECKBOX            
     
     checkbox_flag = false;
     slider_flag = true;
     var basepathval = $("#basepath").val();  
     var year_range = value.split(";");
     from_year = parseInt(year_range[0]);
     to_year = parseInt(year_range[1]);
     
     $("#yearstartspan").html(from_year);
     $("#yearendspan").html(to_year);
     
     var extra_url = $("#display_photos_url").val();
     if(extra_url == '' || extra_url == undefined)
     {
     var pageurl = baseURL+"/get_ajax_photos_data";
     }
     else
     {
     var pageurl = baseURL+"/get_ajax_photos_data/"+extra_url;
     }
     
     if(ajaxFlag == false){
     $.ajax({
     type: "POST", 
     url: pageurl,
     dataType: 'json',
     data: {
     language : lang, 
     from_year : from_year, 
     to_year: to_year,
     global_search_keyword: global_search_keyword
     },
     beforeSend: function ( ) {
     ajaxFlag = true;
     $("#GalleryLoaderDisplay").show();
     },
     success: function(data) {
     
     var photoList = '<form name="photoForm" id="photoForm" action="" method="post"><div style="display:inline;"><input type="hidden" name="global_search_keyword" id="global_search_keyword" value="'+global_search_keyword+'" /><input type="hidden" name="baseUrl" id="baseUrl" value="'+$("#baseUrl").val()+'" /><input type="hidden" name="selected_checkbox" id="selected_checkbox" value="'+$("#selected_checkbox").val()+'" /><input type="hidden" name="language" id="language" value="'+$("#language").val()+'" /><input type="hidden" name="photo_url" id="photo_url" value="'+$("#photo_url").val()+'" /><input type="hidden" name="photo_small_url" id="photo_small_url" value="'+$("#photo_small_url").val()+'" /><input type="hidden" name="photo_medium_url" id="photo_medium_url" value="'+$("#photo_medium_url").val()+'" /><input type="hidden" name="paging" id="paging" value="15" /><input type="hidden" name="totalRecords" id="totalRecords" value="'+$("#totalRecords").val()+'" /></div><div class="galleryCon"><div id="gallery" class="ad-gallery"><div class="ad-nav"><div class="ad-thumbs"><ul class="ad-thumb-list" id="photoListUl">';
     
     var photoDesc = ''; 
     var displayDesc = '';
     var total_data = data.length;   
     
     if(data.length > 0){
     
     // REMOVE ALL HTML
     $("#booksAllDiv").html('');
     
     if( data[total_data-1].total_records == 0){
     photoList = '<div class="galleryCon" style="min-height: 36px; text-align: center; font-weight: bold;">No Record Found.</div>'; 
     $("#printButton").css('display','none');
     }else{
     $("#printButton").css('display','');                        
     for(var i=0; i<total_data-2; i++){
     smallImage   = photo_small_url+data[i].photo_filename;
     mediumImage  = photo_medium_url+data[i].photo_filename;
     orgImage     = photo_url+data[i].photo_filename;
     
     if(i == 0){
     photoClass = 'image0';
     displayDesc = '';
     }else{
     photoClass = 'image1';
     displayDesc = 'none';
     }
     
     photoList += '<li id="gandhiphoto'+i+'"><a href="'+orgImage+'" title="'+$.fn.stripslashes(data[i].photo_title)+'"><img src="'+smallImage+'"  width="42" height="42" alt="'+$.fn.stripslashes(data[i].photo_title)+'"  class="'+photoClass+'" style="vertical-align: middle;" /></a> <input type="hidden" name="year" value="'+data[i].photoyear+'" /></li>';
     
     photoDesc += '<div class="gallery_inner" id="photoDescription'+i+'" style="display:'+displayDesc+'">';
     
     if(data[i].photo_title != '')
     {
     photoDesc += '<h3>'+phototitle+': <span class="phototitle">'+$.fn.stripslashes(data[i].photo_title)+'</span></h3>';
     }
     
     if(data[i].photo_description != '')
     {
     photoDesc += '<h3>'+photodesc+': <span class="photodesc">'+$.fn.stripslashes(data[i].photo_description)+'</span></h3>';
     }
     
     if(data[i].photo_place != '')
     {
     photoDesc += '<h3>'+photoplace+': <span class="photodesc">'+$.fn.stripslashes(data[i].photo_place)+'</span></h3>';
     }
     
     if(data[i].photo_people != '')
     {
     photoDesc += '<h3>'+photopeople+': <span class="photodesc">'+$.fn.stripslashes(data[i].photo_people)+'</span></h3>';
     }
     if(data[i].photo_source != '')
     {
     photoDesc += '<h3>'+photosource+': <span class="photodesc">'+$.fn.stripslashes(data[i].photo_source)+'</span></h3>';
     }
     photoDesc +='</div>';
     
     }
     photoList += '</ul></div></div><div class="ad-image-bg"><div class="ad-image-wrapper"></div></div></div>';
     if(data[total_data-2].extra_url_response != '')
     {
     photoList += '<input type="hidden" name="display_photos_url" id="display_photos_url" value="'+data[total_data-1].extra_url_response+'" />';
     }
     
     photoList += '</div><div class="clearfix"></div>';
     }
     
     photoDesc += '</form>';
     $("#booksAllDiv").html(photoList+photoDesc);
     // START RELOAD GALLERY
     $('div #photoSmallNext').remove();
     $('div #photoSmallPrev').remove();                    
     var galleries =  $('.ad-gallery').adGallery({
     current_index: 0,
     callbacks:{
     init:function(){
     this.preloadAll();
     //this.slideshow.start();
     //this.current_index = 0;
     //clearInterval(this.countdown_interval);
     }
     }
     });
     // STOP RELOAD GALLERY
     
     // CHANGE PAGING
     $('#totalRecords').val(data[total_data-1].total_records);
     
     // HIDE LOADING
     //$('#photoLoading').hide();                    
     }
     else
     {    
     }
     ajaxFlag = false;
     $("#GalleryLoaderDisplay").hide();
     }
     });
     }
     } 
     });
     */
    /* END CODE */

    $.fn.stripslashes = function (str) {
        str = str.replace(/\\'/g, '\'');
        str = str.replace(/\\"/g, '"');
        str = str.replace(/\\\\/g, '\\');
        str = str.replace(/\\0/g, '\0');
        return str;
    };


    String.prototype.filename = function (extension) {
        var s = this.replace(/\\/g, '/');
        s = s.substring(s.lastIndexOf('/') + 1);
        return s;
        //    return extension? s.replace(/[?#].+$/, ''): s.split('.')[0];
    }


    /* START FOR FOR PRINT */
    $("#printPhotos").click(function () {

        $('input:radio[name=print_option]').each(function () {
            if ($(this).val() == '4x6')
            {
                $(this).attr('checked', 'checked');
            }
            else
            {
                $(this).removeAttr('checked');
            }
        });
    });

    $("#printPhotos").fancybox({
        'titleShow': false,
        'transitionIn': 'elastic',
        'transitionOut': 'fade'
    });

    $("#printCancel").click(function () {
        $.fancybox.close();
    });
    /* START FOR FOR PRINT */

    /* RESIZE CALL */


    /*Photo download link for standard view*/
    $('#photoDownload').click(function () {
        //alert($('.ad-image').find('img').attr('src')); 
        //alert($('.pop').attr('href')); return false;
        var baseURL = $('#baseUrl').val();
        var loc = $('.pop').attr('href');
        var image = loc.split('/');
        //var photo_name = image[9];
        //var photo_id = photo_name;
        var photo_id = image[image.length - 1];
        //alert(photo_id); return false;
        location.href = baseURL + '/photoDownload/' + b64.encode(photo_id);
        return false;
    });

});

function print_photos(base_url)
{
    var selected_print_option = $('input:radio[name=print_option]:checked').val();
    var currentImage = $('.ad-image a img').attr('src');
    var imageArray = currentImage.split('/');
    var imageName = imageArray.pop();
    var photoPath = $('#photo_url').val();
    if (imageName != '') {
        var autoclose_second_limit = 1000;
        var imageURL = photoPath + 'print/' + selected_print_option + '/' + imageName;

        var content = '<table width="100%" border="0">';
        content += '<tr>';
        content += '<td width="100%" align="center">';
        content += '<img src="' + imageURL + '" alt="" title="" />';
        content += '</td>';
        content += '</tr>';
        content += '</table>';

        //if(navigator.appVersion.indexOf("MSIE 7.") != -1)
        if (navigator.appVersion.indexOf("Chrome") != -1 || navigator.appVersion.indexOf("MSIE") != -1)
        {
            if (navigator.appVersion.indexOf("Chrome") != -1)
            {
                var pwin = window.open('', 'PrintContent', 'width=600,height=600');
            }
            else
            {
                var pwin = window.open('', 'PrintContent', 'width=10,height=10');
            }
            pwin.document.open();
            pwin.document.write('<html><body onload="window.print();">' + content + '</body></html>');
            pwin.document.close();
            setTimeout(function () {
                pwin.close();
            }, autoclose_second_limit);
        }
        else
        {
            $("#printcontent").html(content);
            $("#printcontent").print();
        }
    }
}

