function delete_photo(pid,langCode)
{
    var flag = confirm("Are you really sure, you want to delete this photo?");
    if(flag == true)    
    {
        document.frmGHPPhotos.del_id.value = pid;
        document.frmGHPPhotos.lang_code.value = langCode;
        document.frmGHPPhotos.submit();
    }    
}

function toggleCheckboxes() {
   
    var inputlist = document.getElementsByTagName("input"); 
    var allChecked = false;
    for (i = 0; i < inputlist.length; i++) {
            
        if ( inputlist[i].getAttribute("type") == 'checkbox' ) {	// look only at input elements that are checkboxes
            if (inputlist[i].checked)
            {
                inputlist[i].checked = false;
                allChecked = false;
            }
            else
            {
                inputlist[i].checked = true;
                allChecked = true;
            }
        }
    }

    if(allChecked == false){
        document.getElementById("photocheckall").checked=false;
        document.frmGHPPhotos.photocheckall.checked = false;
        jQuery("#photocheckall").removeAttr('checked');
    }else{
        document.getElementById("photocheckall").checked=true;
        document.frmGHPPhotos.photocheckall.checked = true;
        jQuery("#photocheckall").attr('checked',"true");
    }
}

function photolistform(val)
{
    var basepathurl = document.getElementById("baseurlpath").value;
    var adminRenamePath = document.getElementById("adminRenamePath").value;
    var checked_num = jQuery('input[name="photoselect[]"]:checked').length; //Added by Maya for multiple delete
    if(checked_num === 0)
    {
        alert("Please select record(s)");return false;
    }
    if(val == "Publish")
    {
        document.frmGHPPhotos.action =basepathurl+"/"+adminRenamePath+"/ghp_photos/publish" ;
        document.frmGHPPhotos.submit();
    }
    else if(val == "Approve")
    {
        document.frmGHPPhotos.action =basepathurl+"/"+adminRenamePath+"/ghp_photos/approve" ;
        document.frmGHPPhotos.submit();
    }
     else if(val == "Unpublish")
    {
        document.frmGHPPhotos.action =basepathurl+"/"+adminRenamePath+"/ghp_photos/unpublish" ;
        document.frmGHPPhotos.submit();
    }
     else if(val == "Reject")
    {
        document.frmGHPPhotos.action =basepathurl+"/"+adminRenamePath+"/ghp_photos/reject" ;
        document.frmGHPPhotos.submit();
    }
    else if(val == "Deleteall")
    { 
        var flag = confirm("Are you really sure, you want to delete these photos?");
        if(flag === true){
            document.frmGHPPhotos.action =basepathurl+"/"+adminRenamePath+"/ghp_photos/deleteall";
            document.frmGHPPhotos.submit();
        }
    }  
}