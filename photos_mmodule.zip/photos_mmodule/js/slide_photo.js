jQuery(function($){
    
    var baseurlvar = $("#baseurl").val();
	$('.copyrightToggle').toggle(function() {
		$('#copyrightClass').stop(1).slideDown('slow');
		$('#arrowimage').attr('src',baseurlvar+'/sites/default/files/photos/images/uparrow.png');
	}, function(){
		$('#copyrightClass').stop(1).slideUp('slow');
		$('#arrowimage').attr('src',baseurlvar+'/sites/default/files/photos/images/downarrow.png');  
	});
});